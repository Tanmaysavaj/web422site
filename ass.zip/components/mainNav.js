import { useAtom } from 'jotai';
import { useRouter } from 'next/router';
import { Navbar, Nav } from 'react-bootstrap';
import { readToken, removeToken } from '../lib/authenticate';
import { searchHistoryAtom } from '../store';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function MainNav() {
  const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // update on route change to reflect login state
    const handleRouteChange = () => {
      setIsLoggedIn(!!readToken());
    };

    handleRouteChange(); // check on first render
    router.events.on('routeChangeComplete', handleRouteChange); // check on every route change

    return () => {
      router.events.off('routeChangeComplete', handleRouteChange);
    };
  }, [router.events]);

  function logout() {
    setSearchHistory([]);
    removeToken();
    setIsLoggedIn(false);
    router.push('/login');
  }

  return (
    <Navbar bg="light" expand="lg" className="fixed-top">
      <Navbar.Brand as={Link} href="/">Tanmay Savaj</Navbar.Brand>
      <Navbar.Toggle aria-controls="main-navbar" />
      <Navbar.Collapse id="main-navbar">
        <Nav className="me-auto">
          <Nav.Link as={Link} href="/">Home</Nav.Link>
        </Nav>
        <Nav>
          {!isLoggedIn ? (
            <>
              <Nav.Link as={Link} href="/register">Register</Nav.Link>
              <Nav.Link as={Link} href="/login">Log In</Nav.Link>
            </>
          ) : (
            <Nav.Link onClick={logout}>Logout</Nav.Link>
          )}
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
}
