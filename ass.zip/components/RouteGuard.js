import { useEffect } from "react";
import { useRouter } from "next/router";
import { useAtom } from "jotai";
import { favouritesAtom, searchHistoryAtom } from "../store";
import { getFavourites, getHistory } from "../lib/userData";
import { getToken } from "../lib/authenticate";

const PUBLIC_PATHS = ["/login", "/register"];

export default function RouteGuard(props) {
  const router = useRouter();
  const [favourites, setFavourites] = useAtom(favouritesAtom);
  const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);

  async function updateAtoms() {
    const token = getToken();
    if (token) {
      try {
        const favs = await getFavourites();
        const hist = await getHistory();
        setFavourites(favs);
        setSearchHistory(hist);
      } catch (err) {
        console.error("Error updating atoms:", err);
      }
    }
  }

  useEffect(() => {
    const authCheck = async () => {
      const token = getToken();
      const path = router.pathname;

      if (!token && !PUBLIC_PATHS.includes(path)) {
        router.push("/login");
      } else {
        await updateAtoms(); // Populate favourites and history on first mount
      }
    };

    authCheck();
  }, [router.pathname]);

  return <>{props.children}</>;
}
