import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { ListGroup, Button, Card } from "react-bootstrap";
import { getHistory, removeFromHistory } from "../lib/userData";

export default function History() {
  const [history, setHistory] = useState([]);
  const router = useRouter();

  // Load history on page load
  useEffect(() => {
    async function loadHistory() {
      const hist = await getHistory();
      setHistory(hist);
    }
    loadHistory();
  }, []);

  // Convert search strings to displayable objects
  let parsedHistory = [];
  history.forEach((h) => {
    let params = new URLSearchParams(h);
    parsedHistory.push(Object.fromEntries(params.entries()));
  });

  // Handle click on item
  function historyClicked(index) {
    router.push(`/artwork?${history[index]}`);
  }

  // Remove item from history
  async function removeHistoryClicked(e, index) {
    e.stopPropagation(); // prevent click bubbling
    const updatedHistory = await removeFromHistory(history[index]);
    setHistory(updatedHistory);
  }

  if (parsedHistory.length === 0) {
    return (
      <Card>
        <Card.Body>
          <h4>Nothing Here</h4>
          <p>Try searching for some artwork.</p>
        </Card.Body>
      </Card>
    );
  }

  return (
    <>
      <h1>Search History</h1>
      <ListGroup>
        {parsedHistory.map((item, index) => (
          <ListGroup.Item
            key={index}
            action
            onClick={() => historyClicked(index)}
            style={{ cursor: "pointer" }}
          >
            {Object.keys(item).map((key) => (
              <span key={key}>
                {key}: <strong>{item[key]}</strong>&nbsp;
              </span>
            ))}
            <Button
              variant="danger"
              size="sm"
              className="float-end"
              onClick={(e) => removeHistoryClicked(e, index)}
            >
              &times;
            </Button>
          </ListGroup.Item>
        ))}
      </ListGroup>
    </>
  );
}
