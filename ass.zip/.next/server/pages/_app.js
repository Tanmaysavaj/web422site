/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "(pages-dir-node)/./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _mainNav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mainNav */ \"(pages-dir-node)/./components/mainNav.js\");\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"(pages-dir-node)/__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_mainNav__WEBPACK_IMPORTED_MODULE_1__]);\n_mainNav__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction Layout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mainNav__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\Layout.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n                style: {\n                    paddingTop: '80px'\n                },\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\Layout.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvTGF5b3V0LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFnQztBQUNZO0FBRTdCLFNBQVNFLE9BQU8sRUFBRUMsUUFBUSxFQUFFO0lBQ3pDLHFCQUNFOzswQkFDRSw4REFBQ0gsZ0RBQU9BOzs7OzswQkFDUiw4REFBQ0MsdUZBQVNBO2dCQUFDRyxPQUFPO29CQUFFQyxZQUFZO2dCQUFPOzBCQUNwQ0Y7Ozs7Ozs7O0FBSVQiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQURNSU5cXERlc2t0b3BcXFdlYjQyMlxcQXNzLTZcXGFzc2lnbm1lbnQtNlxcY29tcG9uZW50c1xcTGF5b3V0LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBNYWluTmF2IGZyb20gJy4vbWFpbk5hdic7XHJcbmltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJ3JlYWN0LWJvb3RzdHJhcCc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXQoeyBjaGlsZHJlbiB9KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxNYWluTmF2IC8+XHJcbiAgICAgIDxDb250YWluZXIgc3R5bGU9e3sgcGFkZGluZ1RvcDogJzgwcHgnIH19PlxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgPC9Db250YWluZXI+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJNYWluTmF2IiwiQ29udGFpbmVyIiwiTGF5b3V0IiwiY2hpbGRyZW4iLCJzdHlsZSIsInBhZGRpbmdUb3AiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/Layout.js\n");

/***/ }),

/***/ "(pages-dir-node)/./components/RouteGuard.js":
/*!**********************************!*\
  !*** ./components/RouteGuard.js ***!
  \**********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RouteGuard)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"(pages-dir-node)/./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../store */ \"(pages-dir-node)/./store.js\");\n/* harmony import */ var _lib_userData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../lib/userData */ \"(pages-dir-node)/./lib/userData.js\");\n/* harmony import */ var _lib_authenticate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../lib/authenticate */ \"(pages-dir-node)/./lib/authenticate.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__, _lib_userData__WEBPACK_IMPORTED_MODULE_5__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_6__]);\n([jotai__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__, _lib_userData__WEBPACK_IMPORTED_MODULE_5__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\nconst PUBLIC_PATHS = [\n    \"/login\",\n    \"/register\"\n];\nfunction RouteGuard(props) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const [favourites, setFavourites] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_4__.favouritesAtom);\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_4__.searchHistoryAtom);\n    async function updateAtoms() {\n        const token = (0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_6__.getToken)();\n        if (token) {\n            try {\n                const favs = await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_5__.getFavourites)();\n                const hist = await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_5__.getHistory)();\n                setFavourites(favs);\n                setSearchHistory(hist);\n            } catch (err) {\n                console.error(\"Error updating atoms:\", err);\n            }\n        }\n    }\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)({\n        \"RouteGuard.useEffect\": ()=>{\n            const authCheck = {\n                \"RouteGuard.useEffect.authCheck\": async ()=>{\n                    const token = (0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_6__.getToken)();\n                    const path = router.pathname;\n                    if (!token && !PUBLIC_PATHS.includes(path)) {\n                        router.push(\"/login\");\n                    } else {\n                        await updateAtoms(); // Populate favourites and history on first mount\n                    }\n                }\n            }[\"RouteGuard.useEffect.authCheck\"];\n            authCheck();\n        }\n    }[\"RouteGuard.useEffect\"], [\n        router.pathname\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: props.children\n    }, void 0, false);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvUm91dGVHdWFyZC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBa0M7QUFDTTtBQUNSO0FBQzZCO0FBQ0Q7QUFDYjtBQUUvQyxNQUFNUSxlQUFlO0lBQUM7SUFBVTtDQUFZO0FBRTdCLFNBQVNDLFdBQVdDLEtBQUs7SUFDdEMsTUFBTUMsU0FBU1Ysc0RBQVNBO0lBQ3hCLE1BQU0sQ0FBQ1csWUFBWUMsY0FBYyxHQUFHWCw4Q0FBT0EsQ0FBQ0Msa0RBQWNBO0lBQzFELE1BQU0sQ0FBQ1csZUFBZUMsaUJBQWlCLEdBQUdiLDhDQUFPQSxDQUFDRSxxREFBaUJBO0lBRW5FLGVBQWVZO1FBQ2IsTUFBTUMsUUFBUVYsMkRBQVFBO1FBQ3RCLElBQUlVLE9BQU87WUFDVCxJQUFJO2dCQUNGLE1BQU1DLE9BQU8sTUFBTWIsNERBQWFBO2dCQUNoQyxNQUFNYyxPQUFPLE1BQU1iLHlEQUFVQTtnQkFDN0JPLGNBQWNLO2dCQUNkSCxpQkFBaUJJO1lBQ25CLEVBQUUsT0FBT0MsS0FBSztnQkFDWkMsUUFBUUMsS0FBSyxDQUFDLHlCQUF5QkY7WUFDekM7UUFDRjtJQUNGO0lBRUFwQixnREFBU0E7Z0NBQUM7WUFDUixNQUFNdUI7a0RBQVk7b0JBQ2hCLE1BQU1OLFFBQVFWLDJEQUFRQTtvQkFDdEIsTUFBTWlCLE9BQU9iLE9BQU9jLFFBQVE7b0JBRTVCLElBQUksQ0FBQ1IsU0FBUyxDQUFDVCxhQUFha0IsUUFBUSxDQUFDRixPQUFPO3dCQUMxQ2IsT0FBT2dCLElBQUksQ0FBQztvQkFDZCxPQUFPO3dCQUNMLE1BQU1YLGVBQWUsaURBQWlEO29CQUN4RTtnQkFDRjs7WUFFQU87UUFDRjsrQkFBRztRQUFDWixPQUFPYyxRQUFRO0tBQUM7SUFFcEIscUJBQU87a0JBQUdmLE1BQU1rQixRQUFROztBQUMxQiIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBRE1JTlxcRGVza3RvcFxcV2ViNDIyXFxBc3MtNlxcYXNzaWdubWVudC02XFxjb21wb25lbnRzXFxSb3V0ZUd1YXJkLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgdXNlQXRvbSB9IGZyb20gXCJqb3RhaVwiO1xyXG5pbXBvcnQgeyBmYXZvdXJpdGVzQXRvbSwgc2VhcmNoSGlzdG9yeUF0b20gfSBmcm9tIFwiLi4vc3RvcmVcIjtcclxuaW1wb3J0IHsgZ2V0RmF2b3VyaXRlcywgZ2V0SGlzdG9yeSB9IGZyb20gXCIuLi9saWIvdXNlckRhdGFcIjtcclxuaW1wb3J0IHsgZ2V0VG9rZW4gfSBmcm9tIFwiLi4vbGliL2F1dGhlbnRpY2F0ZVwiO1xyXG5cclxuY29uc3QgUFVCTElDX1BBVEhTID0gW1wiL2xvZ2luXCIsIFwiL3JlZ2lzdGVyXCJdO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUm91dGVHdWFyZChwcm9wcykge1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG4gIGNvbnN0IFtmYXZvdXJpdGVzLCBzZXRGYXZvdXJpdGVzXSA9IHVzZUF0b20oZmF2b3VyaXRlc0F0b20pO1xyXG4gIGNvbnN0IFtzZWFyY2hIaXN0b3J5LCBzZXRTZWFyY2hIaXN0b3J5XSA9IHVzZUF0b20oc2VhcmNoSGlzdG9yeUF0b20pO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiB1cGRhdGVBdG9tcygpIHtcclxuICAgIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcclxuICAgIGlmICh0b2tlbikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGZhdnMgPSBhd2FpdCBnZXRGYXZvdXJpdGVzKCk7XHJcbiAgICAgICAgY29uc3QgaGlzdCA9IGF3YWl0IGdldEhpc3RvcnkoKTtcclxuICAgICAgICBzZXRGYXZvdXJpdGVzKGZhdnMpO1xyXG4gICAgICAgIHNldFNlYXJjaEhpc3RvcnkoaGlzdCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBhdG9tczpcIiwgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGF1dGhDaGVjayA9IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgdG9rZW4gPSBnZXRUb2tlbigpO1xyXG4gICAgICBjb25zdCBwYXRoID0gcm91dGVyLnBhdGhuYW1lO1xyXG5cclxuICAgICAgaWYgKCF0b2tlbiAmJiAhUFVCTElDX1BBVEhTLmluY2x1ZGVzKHBhdGgpKSB7XHJcbiAgICAgICAgcm91dGVyLnB1c2goXCIvbG9naW5cIik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgYXdhaXQgdXBkYXRlQXRvbXMoKTsgLy8gUG9wdWxhdGUgZmF2b3VyaXRlcyBhbmQgaGlzdG9yeSBvbiBmaXJzdCBtb3VudFxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGF1dGhDaGVjaygpO1xyXG4gIH0sIFtyb3V0ZXIucGF0aG5hbWVdKTtcclxuXHJcbiAgcmV0dXJuIDw+e3Byb3BzLmNoaWxkcmVufTwvPjtcclxufVxyXG4iXSwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUm91dGVyIiwidXNlQXRvbSIsImZhdm91cml0ZXNBdG9tIiwic2VhcmNoSGlzdG9yeUF0b20iLCJnZXRGYXZvdXJpdGVzIiwiZ2V0SGlzdG9yeSIsImdldFRva2VuIiwiUFVCTElDX1BBVEhTIiwiUm91dGVHdWFyZCIsInByb3BzIiwicm91dGVyIiwiZmF2b3VyaXRlcyIsInNldEZhdm91cml0ZXMiLCJzZWFyY2hIaXN0b3J5Iiwic2V0U2VhcmNoSGlzdG9yeSIsInVwZGF0ZUF0b21zIiwidG9rZW4iLCJmYXZzIiwiaGlzdCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImF1dGhDaGVjayIsInBhdGgiLCJwYXRobmFtZSIsImluY2x1ZGVzIiwicHVzaCIsImNoaWxkcmVuIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/RouteGuard.js\n");

/***/ }),

/***/ "(pages-dir-node)/./components/mainNav.js":
/*!*******************************!*\
  !*** ./components/mainNav.js ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MainNav)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"(pages-dir-node)/./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! __barrel_optimize__?names=Nav,Navbar!=!react-bootstrap */ \"(pages-dir-node)/__barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _lib_authenticate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/authenticate */ \"(pages-dir-node)/./lib/authenticate.js\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../store */ \"(pages-dir-node)/./store.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ \"(pages-dir-node)/./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_1__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__]);\n([jotai__WEBPACK_IMPORTED_MODULE_1__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\nfunction MainNav() {\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_1__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_4__.searchHistoryAtom);\n    const [isLoggedIn, setIsLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)({\n        \"MainNav.useEffect\": ()=>{\n            // update on route change to reflect login state\n            const handleRouteChange = {\n                \"MainNav.useEffect.handleRouteChange\": ()=>{\n                    setIsLoggedIn(!!(0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_3__.readToken)());\n                }\n            }[\"MainNav.useEffect.handleRouteChange\"];\n            handleRouteChange(); // check on first render\n            router.events.on('routeChangeComplete', handleRouteChange); // check on every route change\n            return ({\n                \"MainNav.useEffect\": ()=>{\n                    router.events.off('routeChangeComplete', handleRouteChange);\n                }\n            })[\"MainNav.useEffect\"];\n        }\n    }[\"MainNav.useEffect\"], [\n        router.events\n    ]);\n    function logout() {\n        setSearchHistory([]);\n        (0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_3__.removeToken)();\n        setIsLoggedIn(false);\n        router.push('/login');\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar, {\n        bg: \"light\",\n        expand: \"lg\",\n        className: \"fixed-top\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Brand, {\n                as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                href: \"/\",\n                children: \"Tanmay Savaj\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                lineNumber: 37,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Toggle, {\n                \"aria-controls\": \"main-navbar\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                lineNumber: 38,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Collapse, {\n                id: \"main-navbar\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav, {\n                        className: \"me-auto\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                            as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                            href: \"/\",\n                            children: \"Home\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                            lineNumber: 41,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                        lineNumber: 40,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav, {\n                        children: !isLoggedIn ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                                    as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                                    href: \"/register\",\n                                    children: \"Register\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                                    lineNumber: 46,\n                                    columnNumber: 15\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                                    as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                                    href: \"/login\",\n                                    children: \"Log In\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                                    lineNumber: 47,\n                                    columnNumber: 15\n                                }, this)\n                            ]\n                        }, void 0, true) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                            onClick: logout,\n                            children: \"Logout\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                            lineNumber: 50,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                        lineNumber: 43,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n        lineNumber: 36,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvbWFpbk5hdi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFnQztBQUNRO0FBQ007QUFDZTtBQUNoQjtBQUNEO0FBQ2Y7QUFFZCxTQUFTVTtJQUN0QixNQUFNLENBQUNDLGVBQWVDLGlCQUFpQixHQUFHWiw4Q0FBT0EsQ0FBQ00scURBQWlCQTtJQUNuRSxNQUFNLENBQUNPLFlBQVlDLGNBQWMsR0FBR04sK0NBQVFBLENBQUM7SUFDN0MsTUFBTU8sU0FBU2Qsc0RBQVNBO0lBRXhCTSxnREFBU0E7NkJBQUM7WUFDUixnREFBZ0Q7WUFDaEQsTUFBTVM7dURBQW9CO29CQUN4QkYsY0FBYyxDQUFDLENBQUNWLDREQUFTQTtnQkFDM0I7O1lBRUFZLHFCQUFxQix3QkFBd0I7WUFDN0NELE9BQU9FLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDLHVCQUF1QkYsb0JBQW9CLDhCQUE4QjtZQUUxRjtxQ0FBTztvQkFDTEQsT0FBT0UsTUFBTSxDQUFDRSxHQUFHLENBQUMsdUJBQXVCSDtnQkFDM0M7O1FBQ0Y7NEJBQUc7UUFBQ0QsT0FBT0UsTUFBTTtLQUFDO0lBRWxCLFNBQVNHO1FBQ1BSLGlCQUFpQixFQUFFO1FBQ25CUCw4REFBV0E7UUFDWFMsY0FBYztRQUNkQyxPQUFPTSxJQUFJLENBQUM7SUFDZDtJQUVBLHFCQUNFLDhEQUFDbkIscUZBQU1BO1FBQUNvQixJQUFHO1FBQVFDLFFBQU87UUFBS0MsV0FBVTs7MEJBQ3ZDLDhEQUFDdEIscUZBQU1BLENBQUN1QixLQUFLO2dCQUFDQyxJQUFJakIsa0RBQUlBO2dCQUFFa0IsTUFBSzswQkFBSTs7Ozs7OzBCQUNqQyw4REFBQ3pCLHFGQUFNQSxDQUFDMEIsTUFBTTtnQkFBQ0MsaUJBQWM7Ozs7OzswQkFDN0IsOERBQUMzQixxRkFBTUEsQ0FBQzRCLFFBQVE7Z0JBQUNDLElBQUc7O2tDQUNsQiw4REFBQzVCLGtGQUFHQTt3QkFBQ3FCLFdBQVU7a0NBQ2IsNEVBQUNyQixrRkFBR0EsQ0FBQ00sSUFBSTs0QkFBQ2lCLElBQUlqQixrREFBSUE7NEJBQUVrQixNQUFLO3NDQUFJOzs7Ozs7Ozs7OztrQ0FFL0IsOERBQUN4QixrRkFBR0E7a0NBQ0QsQ0FBQ1UsMkJBQ0E7OzhDQUNFLDhEQUFDVixrRkFBR0EsQ0FBQ00sSUFBSTtvQ0FBQ2lCLElBQUlqQixrREFBSUE7b0NBQUVrQixNQUFLOzhDQUFZOzs7Ozs7OENBQ3JDLDhEQUFDeEIsa0ZBQUdBLENBQUNNLElBQUk7b0NBQUNpQixJQUFJakIsa0RBQUlBO29DQUFFa0IsTUFBSzs4Q0FBUzs7Ozs7Ozt5REFHcEMsOERBQUN4QixrRkFBR0EsQ0FBQ00sSUFBSTs0QkFBQ3VCLFNBQVNaO3NDQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU12QyIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBRE1JTlxcRGVza3RvcFxcV2ViNDIyXFxBc3MtNlxcYXNzaWdubWVudC02XFxjb21wb25lbnRzXFxtYWluTmF2LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUF0b20gfSBmcm9tICdqb3RhaSc7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IHsgTmF2YmFyLCBOYXYgfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5pbXBvcnQgeyByZWFkVG9rZW4sIHJlbW92ZVRva2VuIH0gZnJvbSAnLi4vbGliL2F1dGhlbnRpY2F0ZSc7XHJcbmltcG9ydCB7IHNlYXJjaEhpc3RvcnlBdG9tIH0gZnJvbSAnLi4vc3RvcmUnO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWFpbk5hdigpIHtcclxuICBjb25zdCBbc2VhcmNoSGlzdG9yeSwgc2V0U2VhcmNoSGlzdG9yeV0gPSB1c2VBdG9tKHNlYXJjaEhpc3RvcnlBdG9tKTtcclxuICBjb25zdCBbaXNMb2dnZWRJbiwgc2V0SXNMb2dnZWRJbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyB1cGRhdGUgb24gcm91dGUgY2hhbmdlIHRvIHJlZmxlY3QgbG9naW4gc3RhdGVcclxuICAgIGNvbnN0IGhhbmRsZVJvdXRlQ2hhbmdlID0gKCkgPT4ge1xyXG4gICAgICBzZXRJc0xvZ2dlZEluKCEhcmVhZFRva2VuKCkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBoYW5kbGVSb3V0ZUNoYW5nZSgpOyAvLyBjaGVjayBvbiBmaXJzdCByZW5kZXJcclxuICAgIHJvdXRlci5ldmVudHMub24oJ3JvdXRlQ2hhbmdlQ29tcGxldGUnLCBoYW5kbGVSb3V0ZUNoYW5nZSk7IC8vIGNoZWNrIG9uIGV2ZXJ5IHJvdXRlIGNoYW5nZVxyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHJvdXRlci5ldmVudHMub2ZmKCdyb3V0ZUNoYW5nZUNvbXBsZXRlJywgaGFuZGxlUm91dGVDaGFuZ2UpO1xyXG4gICAgfTtcclxuICB9LCBbcm91dGVyLmV2ZW50c10pO1xyXG5cclxuICBmdW5jdGlvbiBsb2dvdXQoKSB7XHJcbiAgICBzZXRTZWFyY2hIaXN0b3J5KFtdKTtcclxuICAgIHJlbW92ZVRva2VuKCk7XHJcbiAgICBzZXRJc0xvZ2dlZEluKGZhbHNlKTtcclxuICAgIHJvdXRlci5wdXNoKCcvbG9naW4nKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8TmF2YmFyIGJnPVwibGlnaHRcIiBleHBhbmQ9XCJsZ1wiIGNsYXNzTmFtZT1cImZpeGVkLXRvcFwiPlxyXG4gICAgICA8TmF2YmFyLkJyYW5kIGFzPXtMaW5rfSBocmVmPVwiL1wiPlRhbm1heSBTYXZhajwvTmF2YmFyLkJyYW5kPlxyXG4gICAgICA8TmF2YmFyLlRvZ2dsZSBhcmlhLWNvbnRyb2xzPVwibWFpbi1uYXZiYXJcIiAvPlxyXG4gICAgICA8TmF2YmFyLkNvbGxhcHNlIGlkPVwibWFpbi1uYXZiYXJcIj5cclxuICAgICAgICA8TmF2IGNsYXNzTmFtZT1cIm1lLWF1dG9cIj5cclxuICAgICAgICAgIDxOYXYuTGluayBhcz17TGlua30gaHJlZj1cIi9cIj5Ib21lPC9OYXYuTGluaz5cclxuICAgICAgICA8L05hdj5cclxuICAgICAgICA8TmF2PlxyXG4gICAgICAgICAgeyFpc0xvZ2dlZEluID8gKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxOYXYuTGluayBhcz17TGlua30gaHJlZj1cIi9yZWdpc3RlclwiPlJlZ2lzdGVyPC9OYXYuTGluaz5cclxuICAgICAgICAgICAgICA8TmF2LkxpbmsgYXM9e0xpbmt9IGhyZWY9XCIvbG9naW5cIj5Mb2cgSW48L05hdi5MaW5rPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxOYXYuTGluayBvbkNsaWNrPXtsb2dvdXR9PkxvZ291dDwvTmF2Lkxpbms+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvTmF2PlxyXG4gICAgICA8L05hdmJhci5Db2xsYXBzZT5cclxuICAgIDwvTmF2YmFyPlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbInVzZUF0b20iLCJ1c2VSb3V0ZXIiLCJOYXZiYXIiLCJOYXYiLCJyZWFkVG9rZW4iLCJyZW1vdmVUb2tlbiIsInNlYXJjaEhpc3RvcnlBdG9tIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJMaW5rIiwiTWFpbk5hdiIsInNlYXJjaEhpc3RvcnkiLCJzZXRTZWFyY2hIaXN0b3J5IiwiaXNMb2dnZWRJbiIsInNldElzTG9nZ2VkSW4iLCJyb3V0ZXIiLCJoYW5kbGVSb3V0ZUNoYW5nZSIsImV2ZW50cyIsIm9uIiwib2ZmIiwibG9nb3V0IiwicHVzaCIsImJnIiwiZXhwYW5kIiwiY2xhc3NOYW1lIiwiQnJhbmQiLCJhcyIsImhyZWYiLCJUb2dnbGUiLCJhcmlhLWNvbnRyb2xzIiwiQ29sbGFwc2UiLCJpZCIsIm9uQ2xpY2siXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/mainNav.js\n");

/***/ }),

/***/ "(pages-dir-node)/./lib/authenticate.js":
/*!*****************************!*\
  !*** ./lib/authenticate.js ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   authenticateUser: () => (/* binding */ authenticateUser),\n/* harmony export */   getToken: () => (/* binding */ getToken),\n/* harmony export */   isAuthenticated: () => (/* binding */ isAuthenticated),\n/* harmony export */   readToken: () => (/* binding */ readToken),\n/* harmony export */   registerUser: () => (/* binding */ registerUser),\n/* harmony export */   removeToken: () => (/* binding */ removeToken),\n/* harmony export */   setToken: () => (/* binding */ setToken)\n/* harmony export */ });\n/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jwt-decode */ \"jwt-decode\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jwt_decode__WEBPACK_IMPORTED_MODULE_0__]);\njwt_decode__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nfunction getToken() {\n    return localStorage.getItem(\"access_token\");\n}\nfunction setToken(token) {\n    localStorage.setItem(\"access_token\", token);\n}\nfunction removeToken() {\n    localStorage.removeItem(\"access_token\");\n}\nfunction readToken() {\n    const token = getToken();\n    return token ? (0,jwt_decode__WEBPACK_IMPORTED_MODULE_0__[\"default\"])(token) : null;\n}\n// Check if the user is authenticated\nfunction isAuthenticated() {\n    return !!getToken();\n}\n// Login function\nasync function authenticateUser(user, password) {\n    const res = await fetch(`${\"https://user-api-seven-drab.vercel.app/api/user\"}/login`, {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/json\"\n        },\n        body: JSON.stringify({\n            userName: user,\n            password\n        })\n    });\n    if (res.status === 200) {\n        const data = await res.json();\n        setToken(data.token);\n        return true;\n    } else {\n        const err = await res.json();\n        throw new Error(err.message || \"Invalid login.\");\n    }\n}\n// Register function\nasync function registerUser(user, password, password2) {\n    const res = await fetch(`${\"https://user-api-seven-drab.vercel.app/api/user\"}/register`, {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/json\"\n        },\n        body: JSON.stringify({\n            userName: user,\n            password,\n            password2\n        })\n    });\n    if (res.status === 200) {\n        return true;\n    }\n    return false;\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2xpYi9hdXRoZW50aWNhdGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBbUM7QUFFNUIsU0FBU0M7SUFDZCxPQUFPQyxhQUFhQyxPQUFPLENBQUM7QUFDOUI7QUFFTyxTQUFTQyxTQUFTQyxLQUFLO0lBQzVCSCxhQUFhSSxPQUFPLENBQUMsZ0JBQWdCRDtBQUN2QztBQUVPLFNBQVNFO0lBQ2RMLGFBQWFNLFVBQVUsQ0FBQztBQUMxQjtBQUVPLFNBQVNDO0lBQ2QsTUFBTUosUUFBUUo7SUFDZCxPQUFPSSxRQUFRTCxzREFBU0EsQ0FBQ0ssU0FBUztBQUNwQztBQUlBLHFDQUFxQztBQUM5QixTQUFTSztJQUNkLE9BQU8sQ0FBQyxDQUFDVDtBQUNYO0FBRUEsaUJBQWlCO0FBQ1YsZUFBZVUsaUJBQWlCQyxJQUFJLEVBQUVDLFFBQVE7SUFDbkQsTUFBTUMsTUFBTSxNQUFNQyxNQUFNLEdBQUdDLGlEQUErQixDQUFDLE1BQU0sQ0FBQyxFQUFFO1FBQ2xFRyxRQUFRO1FBQ1JDLFNBQVM7WUFBRSxnQkFBZ0I7UUFBbUI7UUFDOUNDLE1BQU1DLEtBQUtDLFNBQVMsQ0FBQztZQUFFQyxVQUFVWjtZQUFNQztRQUFTO0lBQ2xEO0lBRUEsSUFBSUMsSUFBSVcsTUFBTSxLQUFLLEtBQUs7UUFDdEIsTUFBTUMsT0FBTyxNQUFNWixJQUFJYSxJQUFJO1FBQzNCdkIsU0FBU3NCLEtBQUtyQixLQUFLO1FBQ25CLE9BQU87SUFDVCxPQUFPO1FBQ0wsTUFBTXVCLE1BQU0sTUFBTWQsSUFBSWEsSUFBSTtRQUMxQixNQUFNLElBQUlFLE1BQU1ELElBQUlFLE9BQU8sSUFBSTtJQUNqQztBQUNGO0FBR0Esb0JBQW9CO0FBQ2IsZUFBZUMsYUFBYW5CLElBQUksRUFBRUMsUUFBUSxFQUFFbUIsU0FBUztJQUMxRCxNQUFNbEIsTUFBTSxNQUFNQyxNQUFNLEdBQUdDLGlEQUErQixDQUFDLFNBQVMsQ0FBQyxFQUFFO1FBQ3JFRyxRQUFRO1FBQ1JDLFNBQVM7WUFBRSxnQkFBZ0I7UUFBbUI7UUFDOUNDLE1BQU1DLEtBQUtDLFNBQVMsQ0FBQztZQUNuQkMsVUFBVVo7WUFDVkM7WUFDQW1CO1FBQ0Y7SUFDRjtJQUVBLElBQUlsQixJQUFJVyxNQUFNLEtBQUssS0FBSztRQUN0QixPQUFPO0lBQ1Q7SUFFQSxPQUFPO0FBQ1QiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQURNSU5cXERlc2t0b3BcXFdlYjQyMlxcQXNzLTZcXGFzc2lnbm1lbnQtNlxcbGliXFxhdXRoZW50aWNhdGUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGp3dERlY29kZSBmcm9tIFwiand0LWRlY29kZVwiO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldFRva2VuKCkge1xyXG4gIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImFjY2Vzc190b2tlblwiKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNldFRva2VuKHRva2VuKSB7XHJcbiAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJhY2Nlc3NfdG9rZW5cIiwgdG9rZW4pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlVG9rZW4oKSB7XHJcbiAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oXCJhY2Nlc3NfdG9rZW5cIik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiByZWFkVG9rZW4oKSB7XHJcbiAgY29uc3QgdG9rZW4gPSBnZXRUb2tlbigpO1xyXG4gIHJldHVybiB0b2tlbiA/IGp3dERlY29kZSh0b2tlbikgOiBudWxsO1xyXG59XHJcblxyXG5cclxuXHJcbi8vIENoZWNrIGlmIHRoZSB1c2VyIGlzIGF1dGhlbnRpY2F0ZWRcclxuZXhwb3J0IGZ1bmN0aW9uIGlzQXV0aGVudGljYXRlZCgpIHtcclxuICByZXR1cm4gISFnZXRUb2tlbigpO1xyXG59XHJcblxyXG4vLyBMb2dpbiBmdW5jdGlvblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXV0aGVudGljYXRlVXNlcih1c2VyLCBwYXNzd29yZCkge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke3Byb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9VUkx9L2xvZ2luYCwge1xyXG4gICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdXNlck5hbWU6IHVzZXIsIHBhc3N3b3JkIH0pLFxyXG4gIH0pO1xyXG5cclxuICBpZiAocmVzLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgIHNldFRva2VuKGRhdGEudG9rZW4pO1xyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNvbnN0IGVyciA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoZXJyLm1lc3NhZ2UgfHwgXCJJbnZhbGlkIGxvZ2luLlwiKTtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyBSZWdpc3RlciBmdW5jdGlvblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVnaXN0ZXJVc2VyKHVzZXIsIHBhc3N3b3JkLCBwYXNzd29yZDIpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfS9yZWdpc3RlcmAsIHtcclxuICAgIG1ldGhvZDogXCJQT1NUXCIsXHJcbiAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgIHVzZXJOYW1lOiB1c2VyLFxyXG4gICAgICBwYXNzd29yZCxcclxuICAgICAgcGFzc3dvcmQyLFxyXG4gICAgfSksXHJcbiAgfSk7XHJcblxyXG4gIGlmIChyZXMuc3RhdHVzID09PSAyMDApIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGZhbHNlO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJqd3REZWNvZGUiLCJnZXRUb2tlbiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzZXRUb2tlbiIsInRva2VuIiwic2V0SXRlbSIsInJlbW92ZVRva2VuIiwicmVtb3ZlSXRlbSIsInJlYWRUb2tlbiIsImlzQXV0aGVudGljYXRlZCIsImF1dGhlbnRpY2F0ZVVzZXIiLCJ1c2VyIiwicGFzc3dvcmQiLCJyZXMiLCJmZXRjaCIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19BUElfVVJMIiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwidXNlck5hbWUiLCJzdGF0dXMiLCJkYXRhIiwianNvbiIsImVyciIsIkVycm9yIiwibWVzc2FnZSIsInJlZ2lzdGVyVXNlciIsInBhc3N3b3JkMiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(pages-dir-node)/./lib/authenticate.js\n");

/***/ }),

/***/ "(pages-dir-node)/./lib/userData.js":
/*!*************************!*\
  !*** ./lib/userData.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   addToFavourites: () => (/* binding */ addToFavourites),\n/* harmony export */   addToHistory: () => (/* binding */ addToHistory),\n/* harmony export */   getFavourites: () => (/* binding */ getFavourites),\n/* harmony export */   getHistory: () => (/* binding */ getHistory),\n/* harmony export */   removeFromFavourites: () => (/* binding */ removeFromFavourites),\n/* harmony export */   removeFromHistory: () => (/* binding */ removeFromHistory)\n/* harmony export */ });\n/* harmony import */ var _authenticate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authenticate */ \"(pages-dir-node)/./lib/authenticate.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_authenticate__WEBPACK_IMPORTED_MODULE_0__]);\n_authenticate__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst API_URL = \"https://user-api-seven-drab.vercel.app/api/user\";\n// Helper to add headers\nfunction getAuthHeaders() {\n    return {\n        \"Content-Type\": \"application/json\",\n        Authorization: `JWT ${(0,_authenticate__WEBPACK_IMPORTED_MODULE_0__.getToken)()}`\n    };\n}\n// Add to favourites\nasync function addToFavourites(id) {\n    const res = await fetch(`${API_URL}/favourites/${id}`, {\n        method: \"PUT\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Remove from favourites\nasync function removeFromFavourites(id) {\n    const res = await fetch(`${API_URL}/favourites/${id}`, {\n        method: \"DELETE\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Get favourites\nasync function getFavourites() {\n    const res = await fetch(`${API_URL}/favourites`, {\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Add to history\nasync function addToHistory(id) {\n    const res = await fetch(`${API_URL}/history/${id}`, {\n        method: \"PUT\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Remove from history\nasync function removeFromHistory(id) {\n    const res = await fetch(`${API_URL}/history/${id}`, {\n        method: \"DELETE\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Get history\nasync function getHistory() {\n    const res = await fetch(`${API_URL}/history`, {\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2xpYi91c2VyRGF0YS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQTBDO0FBRTFDLE1BQU1DLFVBQVVDLGlEQUErQjtBQUUvQyx3QkFBd0I7QUFDeEIsU0FBU0c7SUFDUCxPQUFPO1FBQ0wsZ0JBQWdCO1FBQ2hCQyxlQUFlLENBQUMsSUFBSSxFQUFFTix1REFBUUEsSUFBSTtJQUNwQztBQUNGO0FBRUEsb0JBQW9CO0FBQ2IsZUFBZU8sZ0JBQWdCQyxFQUFFO0lBQ3RDLE1BQU1DLE1BQU0sTUFBTUMsTUFBTSxHQUFHVCxRQUFRLFlBQVksRUFBRU8sSUFBSSxFQUFFO1FBQ3JERyxRQUFRO1FBQ1JDLFNBQVNQO0lBQ1g7SUFFQSxPQUFPSSxJQUFJSSxNQUFNLEtBQUssTUFBTUosSUFBSUssSUFBSSxLQUFLLEVBQUU7QUFDN0M7QUFFQSx5QkFBeUI7QUFDbEIsZUFBZUMscUJBQXFCUCxFQUFFO0lBQzNDLE1BQU1DLE1BQU0sTUFBTUMsTUFBTSxHQUFHVCxRQUFRLFlBQVksRUFBRU8sSUFBSSxFQUFFO1FBQ3JERyxRQUFRO1FBQ1JDLFNBQVNQO0lBQ1g7SUFFQSxPQUFPSSxJQUFJSSxNQUFNLEtBQUssTUFBTUosSUFBSUssSUFBSSxLQUFLLEVBQUU7QUFDN0M7QUFFQSxpQkFBaUI7QUFDVixlQUFlRTtJQUNwQixNQUFNUCxNQUFNLE1BQU1DLE1BQU0sR0FBR1QsUUFBUSxXQUFXLENBQUMsRUFBRTtRQUMvQ1csU0FBU1A7SUFDWDtJQUVBLE9BQU9JLElBQUlJLE1BQU0sS0FBSyxNQUFNSixJQUFJSyxJQUFJLEtBQUssRUFBRTtBQUM3QztBQUVBLGlCQUFpQjtBQUNWLGVBQWVHLGFBQWFULEVBQUU7SUFDbkMsTUFBTUMsTUFBTSxNQUFNQyxNQUFNLEdBQUdULFFBQVEsU0FBUyxFQUFFTyxJQUFJLEVBQUU7UUFDbERHLFFBQVE7UUFDUkMsU0FBU1A7SUFDWDtJQUVBLE9BQU9JLElBQUlJLE1BQU0sS0FBSyxNQUFNSixJQUFJSyxJQUFJLEtBQUssRUFBRTtBQUM3QztBQUVBLHNCQUFzQjtBQUNmLGVBQWVJLGtCQUFrQlYsRUFBRTtJQUN4QyxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sR0FBR1QsUUFBUSxTQUFTLEVBQUVPLElBQUksRUFBRTtRQUNsREcsUUFBUTtRQUNSQyxTQUFTUDtJQUNYO0lBRUEsT0FBT0ksSUFBSUksTUFBTSxLQUFLLE1BQU1KLElBQUlLLElBQUksS0FBSyxFQUFFO0FBQzdDO0FBRUEsY0FBYztBQUNQLGVBQWVLO0lBQ3BCLE1BQU1WLE1BQU0sTUFBTUMsTUFBTSxHQUFHVCxRQUFRLFFBQVEsQ0FBQyxFQUFFO1FBQzVDVyxTQUFTUDtJQUNYO0lBRUEsT0FBT0ksSUFBSUksTUFBTSxLQUFLLE1BQU1KLElBQUlLLElBQUksS0FBSyxFQUFFO0FBQzdDIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXEFETUlOXFxEZXNrdG9wXFxXZWI0MjJcXEFzcy02XFxhc3NpZ25tZW50LTZcXGxpYlxcdXNlckRhdGEuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ2V0VG9rZW4gfSBmcm9tIFwiLi9hdXRoZW50aWNhdGVcIjtcclxuXHJcbmNvbnN0IEFQSV9VUkwgPSBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMO1xyXG5cclxuLy8gSGVscGVyIHRvIGFkZCBoZWFkZXJzXHJcbmZ1bmN0aW9uIGdldEF1dGhIZWFkZXJzKCkge1xyXG4gIHJldHVybiB7XHJcbiAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgIEF1dGhvcml6YXRpb246IGBKV1QgJHtnZXRUb2tlbigpfWAsXHJcbiAgfTtcclxufVxyXG5cclxuLy8gQWRkIHRvIGZhdm91cml0ZXNcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFkZFRvRmF2b3VyaXRlcyhpZCkge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9VUkx9L2Zhdm91cml0ZXMvJHtpZH1gLCB7XHJcbiAgICBtZXRob2Q6IFwiUFVUXCIsXHJcbiAgICBoZWFkZXJzOiBnZXRBdXRoSGVhZGVycygpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gcmVzLnN0YXR1cyA9PT0gMjAwID8gcmVzLmpzb24oKSA6IFtdO1xyXG59XHJcblxyXG4vLyBSZW1vdmUgZnJvbSBmYXZvdXJpdGVzXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZW1vdmVGcm9tRmF2b3VyaXRlcyhpZCkge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9VUkx9L2Zhdm91cml0ZXMvJHtpZH1gLCB7XHJcbiAgICBtZXRob2Q6IFwiREVMRVRFXCIsXHJcbiAgICBoZWFkZXJzOiBnZXRBdXRoSGVhZGVycygpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gcmVzLnN0YXR1cyA9PT0gMjAwID8gcmVzLmpzb24oKSA6IFtdO1xyXG59XHJcblxyXG4vLyBHZXQgZmF2b3VyaXRlc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RmF2b3VyaXRlcygpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfVVJMfS9mYXZvdXJpdGVzYCwge1xyXG4gICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwMCA/IHJlcy5qc29uKCkgOiBbXTtcclxufVxyXG5cclxuLy8gQWRkIHRvIGhpc3RvcnlcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFkZFRvSGlzdG9yeShpZCkge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9VUkx9L2hpc3RvcnkvJHtpZH1gLCB7XHJcbiAgICBtZXRob2Q6IFwiUFVUXCIsXHJcbiAgICBoZWFkZXJzOiBnZXRBdXRoSGVhZGVycygpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gcmVzLnN0YXR1cyA9PT0gMjAwID8gcmVzLmpzb24oKSA6IFtdO1xyXG59XHJcblxyXG4vLyBSZW1vdmUgZnJvbSBoaXN0b3J5XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZW1vdmVGcm9tSGlzdG9yeShpZCkge1xyXG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0FQSV9VUkx9L2hpc3RvcnkvJHtpZH1gLCB7XHJcbiAgICBtZXRob2Q6IFwiREVMRVRFXCIsXHJcbiAgICBoZWFkZXJzOiBnZXRBdXRoSGVhZGVycygpLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gcmVzLnN0YXR1cyA9PT0gMjAwID8gcmVzLmpzb24oKSA6IFtdO1xyXG59XHJcblxyXG4vLyBHZXQgaGlzdG9yeVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0SGlzdG9yeSgpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfVVJMfS9oaXN0b3J5YCwge1xyXG4gICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwMCA/IHJlcy5qc29uKCkgOiBbXTtcclxufVxyXG4iXSwibmFtZXMiOlsiZ2V0VG9rZW4iLCJBUElfVVJMIiwicHJvY2VzcyIsImVudiIsIk5FWFRfUFVCTElDX0FQSV9VUkwiLCJnZXRBdXRoSGVhZGVycyIsIkF1dGhvcml6YXRpb24iLCJhZGRUb0Zhdm91cml0ZXMiLCJpZCIsInJlcyIsImZldGNoIiwibWV0aG9kIiwiaGVhZGVycyIsInN0YXR1cyIsImpzb24iLCJyZW1vdmVGcm9tRmF2b3VyaXRlcyIsImdldEZhdm91cml0ZXMiLCJhZGRUb0hpc3RvcnkiLCJyZW1vdmVGcm9tSGlzdG9yeSIsImdldEhpc3RvcnkiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./lib/userData.js\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/bootstrap.min.css */ \"(pages-dir-node)/./styles/bootstrap.min.css\");\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Layout */ \"(pages-dir-node)/./components/Layout.js\");\n/* harmony import */ var _components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/RouteGuard */ \"(pages-dir-node)/./components/RouteGuard.js\");\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swr */ \"swr\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout__WEBPACK_IMPORTED_MODULE_2__, _components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__]);\n([_components_Layout__WEBPACK_IMPORTED_MODULE_2__, _components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(swr__WEBPACK_IMPORTED_MODULE_4__.SWRConfig, {\n        value: {\n            fetcher: async (url)=>{\n                const res = await fetch(url);\n                if (!res.ok) {\n                    const error = new Error('An error occurred while fetching the data.');\n                    error.info = await res.json();\n                    error.status = res.status;\n                    throw error;\n                }\n                return res.json();\n            }\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n                    lineNumber: 22,\n                    columnNumber: 11\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n                lineNumber: 21,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n            lineNumber: 20,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL19hcHAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQW9DO0FBQ007QUFDUTtBQUNsQjtBQUVoQyxTQUFTRyxNQUFNLEVBQUVDLFNBQVMsRUFBRUMsU0FBUyxFQUFFO0lBQ3JDLHFCQUNFLDhEQUFDSCwwQ0FBU0E7UUFBQ0ksT0FBTztZQUNoQkMsU0FBUyxPQUFNQztnQkFDYixNQUFNQyxNQUFNLE1BQU1DLE1BQU1GO2dCQUN4QixJQUFJLENBQUNDLElBQUlFLEVBQUUsRUFBRTtvQkFDWCxNQUFNQyxRQUFRLElBQUlDLE1BQU07b0JBQ3hCRCxNQUFNRSxJQUFJLEdBQUcsTUFBTUwsSUFBSU0sSUFBSTtvQkFDM0JILE1BQU1JLE1BQU0sR0FBR1AsSUFBSU8sTUFBTTtvQkFDekIsTUFBTUo7Z0JBQ1I7Z0JBQ0EsT0FBT0gsSUFBSU0sSUFBSTtZQUNqQjtRQUNGO2tCQUNFLDRFQUFDZCw4REFBVUE7c0JBQ1QsNEVBQUNELDBEQUFNQTswQkFDTCw0RUFBQ0k7b0JBQVcsR0FBR0MsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS2xDO0FBRUEsaUVBQWVGLEtBQUtBLEVBQUMiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQURNSU5cXERlc2t0b3BcXFdlYjQyMlxcQXNzLTZcXGFzc2lnbm1lbnQtNlxccGFnZXNcXF9hcHAuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICdAL3N0eWxlcy9ib290c3RyYXAubWluLmNzcyc7XG5pbXBvcnQgTGF5b3V0IGZyb20gJy4uL2NvbXBvbmVudHMvTGF5b3V0JztcbmltcG9ydCBSb3V0ZUd1YXJkIGZyb20gJy4uL2NvbXBvbmVudHMvUm91dGVHdWFyZCc7XG5pbXBvcnQgeyBTV1JDb25maWcgfSBmcm9tICdzd3InO1xuXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8U1dSQ29uZmlnIHZhbHVlPXt7XG4gICAgICBmZXRjaGVyOiBhc3luYyB1cmwgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwpO1xuICAgICAgICBpZiAoIXJlcy5vaykge1xuICAgICAgICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKCdBbiBlcnJvciBvY2N1cnJlZCB3aGlsZSBmZXRjaGluZyB0aGUgZGF0YS4nKTtcbiAgICAgICAgICBlcnJvci5pbmZvID0gYXdhaXQgcmVzLmpzb24oKTtcbiAgICAgICAgICBlcnJvci5zdGF0dXMgPSByZXMuc3RhdHVzO1xuICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXMuanNvbigpO1xuICAgICAgfVxuICAgIH19PlxuICAgICAgPFJvdXRlR3VhcmQ+XG4gICAgICAgIDxMYXlvdXQ+XG4gICAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgICA8L0xheW91dD5cbiAgICAgIDwvUm91dGVHdWFyZD5cbiAgICA8L1NXUkNvbmZpZz5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTXlBcHA7XG4iXSwibmFtZXMiOlsiTGF5b3V0IiwiUm91dGVHdWFyZCIsIlNXUkNvbmZpZyIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwidmFsdWUiLCJmZXRjaGVyIiwidXJsIiwicmVzIiwiZmV0Y2giLCJvayIsImVycm9yIiwiRXJyb3IiLCJpbmZvIiwianNvbiIsInN0YXR1cyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/_app.js\n");

/***/ }),

/***/ "(pages-dir-node)/./store.js":
/*!******************!*\
  !*** ./store.js ***!
  \******************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   favouritesAtom: () => (/* binding */ favouritesAtom),\n/* harmony export */   searchHistoryAtom: () => (/* binding */ searchHistoryAtom)\n/* harmony export */ });\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jotai */ \"jotai\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_0__]);\njotai__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst favouritesAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\nconst searchHistoryAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3N0b3JlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUE2QjtBQUV0QixNQUFNQyxpQkFBaUJELDJDQUFJQSxDQUFDLEVBQUUsRUFBRTtBQUNoQyxNQUFNRSxvQkFBb0JGLDJDQUFJQSxDQUFDLEVBQUUsRUFBRSIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBRE1JTlxcRGVza3RvcFxcV2ViNDIyXFxBc3MtNlxcYXNzaWdubWVudC02XFxzdG9yZS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhdG9tIH0gZnJvbSAnam90YWknO1xyXG5cclxuZXhwb3J0IGNvbnN0IGZhdm91cml0ZXNBdG9tID0gYXRvbShbXSk7XHJcbmV4cG9ydCBjb25zdCBzZWFyY2hIaXN0b3J5QXRvbSA9IGF0b20oW10pO1xyXG4iXSwibmFtZXMiOlsiYXRvbSIsImZhdm91cml0ZXNBdG9tIiwic2VhcmNoSGlzdG9yeUF0b20iXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./store.js\n");

/***/ }),

/***/ "(pages-dir-node)/./styles/bootstrap.min.css":
/*!**********************************!*\
  !*** ./styles/bootstrap.min.css ***!
  \**********************************/
/***/ (() => {



/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Container */ "(pages-dir-node)/./node_modules/react-bootstrap/esm/Container.js");



/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!******************************************************************************************!*\
  !*** __barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_1__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Nav */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Navbar */ \"(pages-dir-node)/./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS9fX2JhcnJlbF9vcHRpbWl6ZV9fP25hbWVzPU5hdixOYXZiYXIhPSEuL25vZGVfbW9kdWxlcy9yZWFjdC1ib290c3RyYXAvZXNtL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQ3NDIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXEFETUlOXFxEZXNrdG9wXFxXZWI0MjJcXEFzcy02XFxhc3NpZ25tZW50LTZcXG5vZGVfbW9kdWxlc1xccmVhY3QtYm9vdHN0cmFwXFxlc21cXGluZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXYgfSBmcm9tIFwiLi9OYXZcIlxuZXhwb3J0IHsgZGVmYXVsdCBhcyBOYXZiYXIgfSBmcm9tIFwiLi9OYXZiYXJcIiJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOlswXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(pages-dir-node)/__barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "@restart/ui/utils":
/*!************************************!*\
  !*** external "@restart/ui/utils" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/utils");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "jotai":
/*!************************!*\
  !*** external "jotai" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("jotai");;

/***/ }),

/***/ "jwt-decode":
/*!*****************************!*\
  !*** external "jwt-decode" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = import("jwt-decode");;

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "swr":
/*!**********************!*\
  !*** external "swr" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap"], () => (__webpack_exec__("(pages-dir-node)/./pages/_app.js")));
module.exports = __webpack_exports__;

})();