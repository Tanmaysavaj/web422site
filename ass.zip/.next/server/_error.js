/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "/_error";
exports.ids = ["/_error"];
exports.modules = {

/***/ "./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _mainNav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mainNav */ \"./components/mainNav.js\");\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_mainNav__WEBPACK_IMPORTED_MODULE_1__]);\n_mainNav__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction Layout({ children }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_mainNav__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\Layout.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n                style: {\n                    paddingTop: '80px'\n                },\n                children: children\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\Layout.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0xheW91dC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBZ0M7QUFDWTtBQUU3QixTQUFTRSxPQUFPLEVBQUVDLFFBQVEsRUFBRTtJQUN6QyxxQkFDRTs7MEJBQ0UsOERBQUNILGdEQUFPQTs7Ozs7MEJBQ1IsOERBQUNDLHVGQUFTQTtnQkFBQ0csT0FBTztvQkFBRUMsWUFBWTtnQkFBTzswQkFDcENGOzs7Ozs7OztBQUlUIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXEFETUlOXFxEZXNrdG9wXFxXZWI0MjJcXEFzcy02XFxhc3NpZ25tZW50LTZcXGNvbXBvbmVudHNcXExheW91dC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTWFpbk5hdiBmcm9tICcuL21haW5OYXYnO1xyXG5pbXBvcnQgeyBDb250YWluZXIgfSBmcm9tICdyZWFjdC1ib290c3RyYXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0KHsgY2hpbGRyZW4gfSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8TWFpbk5hdiAvPlxyXG4gICAgICA8Q29udGFpbmVyIHN0eWxlPXt7IHBhZGRpbmdUb3A6ICc4MHB4JyB9fT5cclxuICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXSwibmFtZXMiOlsiTWFpbk5hdiIsIkNvbnRhaW5lciIsIkxheW91dCIsImNoaWxkcmVuIiwic3R5bGUiLCJwYWRkaW5nVG9wIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/Layout.js\n");

/***/ }),

/***/ "./components/RouteGuard.js":
/*!**********************************!*\
  !*** ./components/RouteGuard.js ***!
  \**********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ RouteGuard)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../store */ \"./store.js\");\n/* harmony import */ var _lib_userData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../lib/userData */ \"./lib/userData.js\");\n/* harmony import */ var _lib_authenticate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../lib/authenticate */ \"./lib/authenticate.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__, _lib_userData__WEBPACK_IMPORTED_MODULE_5__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_6__]);\n([jotai__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__, _lib_userData__WEBPACK_IMPORTED_MODULE_5__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\nconst PUBLIC_PATHS = [\n    \"/login\",\n    \"/register\"\n];\nfunction RouteGuard(props) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    const [favourites, setFavourites] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_4__.favouritesAtom);\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_3__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_4__.searchHistoryAtom);\n    async function updateAtoms() {\n        const token = (0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_6__.getToken)();\n        if (token) {\n            try {\n                const favs = await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_5__.getFavourites)();\n                const hist = await (0,_lib_userData__WEBPACK_IMPORTED_MODULE_5__.getHistory)();\n                setFavourites(favs);\n                setSearchHistory(hist);\n            } catch (err) {\n                console.error(\"Error updating atoms:\", err);\n            }\n        }\n    }\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)({\n        \"RouteGuard.useEffect\": ()=>{\n            const authCheck = {\n                \"RouteGuard.useEffect.authCheck\": async ()=>{\n                    const token = (0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_6__.getToken)();\n                    const path = router.pathname;\n                    if (!token && !PUBLIC_PATHS.includes(path)) {\n                        router.push(\"/login\");\n                    } else {\n                        await updateAtoms(); // Populate favourites and history on first mount\n                    }\n                }\n            }[\"RouteGuard.useEffect.authCheck\"];\n            authCheck();\n        }\n    }[\"RouteGuard.useEffect\"], [\n        router.pathname\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: props.children\n    }, void 0, false);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL1JvdXRlR3VhcmQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQWtDO0FBQ007QUFDUjtBQUM2QjtBQUNEO0FBQ2I7QUFFL0MsTUFBTVEsZUFBZTtJQUFDO0lBQVU7Q0FBWTtBQUU3QixTQUFTQyxXQUFXQyxLQUFLO0lBQ3RDLE1BQU1DLFNBQVNWLHNEQUFTQTtJQUN4QixNQUFNLENBQUNXLFlBQVlDLGNBQWMsR0FBR1gsOENBQU9BLENBQUNDLGtEQUFjQTtJQUMxRCxNQUFNLENBQUNXLGVBQWVDLGlCQUFpQixHQUFHYiw4Q0FBT0EsQ0FBQ0UscURBQWlCQTtJQUVuRSxlQUFlWTtRQUNiLE1BQU1DLFFBQVFWLDJEQUFRQTtRQUN0QixJQUFJVSxPQUFPO1lBQ1QsSUFBSTtnQkFDRixNQUFNQyxPQUFPLE1BQU1iLDREQUFhQTtnQkFDaEMsTUFBTWMsT0FBTyxNQUFNYix5REFBVUE7Z0JBQzdCTyxjQUFjSztnQkFDZEgsaUJBQWlCSTtZQUNuQixFQUFFLE9BQU9DLEtBQUs7Z0JBQ1pDLFFBQVFDLEtBQUssQ0FBQyx5QkFBeUJGO1lBQ3pDO1FBQ0Y7SUFDRjtJQUVBcEIsZ0RBQVNBO2dDQUFDO1lBQ1IsTUFBTXVCO2tEQUFZO29CQUNoQixNQUFNTixRQUFRViwyREFBUUE7b0JBQ3RCLE1BQU1pQixPQUFPYixPQUFPYyxRQUFRO29CQUU1QixJQUFJLENBQUNSLFNBQVMsQ0FBQ1QsYUFBYWtCLFFBQVEsQ0FBQ0YsT0FBTzt3QkFDMUNiLE9BQU9nQixJQUFJLENBQUM7b0JBQ2QsT0FBTzt3QkFDTCxNQUFNWCxlQUFlLGlEQUFpRDtvQkFDeEU7Z0JBQ0Y7O1lBRUFPO1FBQ0Y7K0JBQUc7UUFBQ1osT0FBT2MsUUFBUTtLQUFDO0lBRXBCLHFCQUFPO2tCQUFHZixNQUFNa0IsUUFBUTs7QUFDMUIiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQURNSU5cXERlc2t0b3BcXFdlYjQyMlxcQXNzLTZcXGFzc2lnbm1lbnQtNlxcY29tcG9uZW50c1xcUm91dGVHdWFyZC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIm5leHQvcm91dGVyXCI7XHJcbmltcG9ydCB7IHVzZUF0b20gfSBmcm9tIFwiam90YWlcIjtcclxuaW1wb3J0IHsgZmF2b3VyaXRlc0F0b20sIHNlYXJjaEhpc3RvcnlBdG9tIH0gZnJvbSBcIi4uL3N0b3JlXCI7XHJcbmltcG9ydCB7IGdldEZhdm91cml0ZXMsIGdldEhpc3RvcnkgfSBmcm9tIFwiLi4vbGliL3VzZXJEYXRhXCI7XHJcbmltcG9ydCB7IGdldFRva2VuIH0gZnJvbSBcIi4uL2xpYi9hdXRoZW50aWNhdGVcIjtcclxuXHJcbmNvbnN0IFBVQkxJQ19QQVRIUyA9IFtcIi9sb2dpblwiLCBcIi9yZWdpc3RlclwiXTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFJvdXRlR3VhcmQocHJvcHMpIHtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBbZmF2b3VyaXRlcywgc2V0RmF2b3VyaXRlc10gPSB1c2VBdG9tKGZhdm91cml0ZXNBdG9tKTtcclxuICBjb25zdCBbc2VhcmNoSGlzdG9yeSwgc2V0U2VhcmNoSGlzdG9yeV0gPSB1c2VBdG9tKHNlYXJjaEhpc3RvcnlBdG9tKTtcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlQXRvbXMoKSB7XHJcbiAgICBjb25zdCB0b2tlbiA9IGdldFRva2VuKCk7XHJcbiAgICBpZiAodG9rZW4pIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBmYXZzID0gYXdhaXQgZ2V0RmF2b3VyaXRlcygpO1xyXG4gICAgICAgIGNvbnN0IGhpc3QgPSBhd2FpdCBnZXRIaXN0b3J5KCk7XHJcbiAgICAgICAgc2V0RmF2b3VyaXRlcyhmYXZzKTtcclxuICAgICAgICBzZXRTZWFyY2hIaXN0b3J5KGhpc3QpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgYXRvbXM6XCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhdXRoQ2hlY2sgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcclxuICAgICAgY29uc3QgcGF0aCA9IHJvdXRlci5wYXRobmFtZTtcclxuXHJcbiAgICAgIGlmICghdG9rZW4gJiYgIVBVQkxJQ19QQVRIUy5pbmNsdWRlcyhwYXRoKSkge1xyXG4gICAgICAgIHJvdXRlci5wdXNoKFwiL2xvZ2luXCIpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IHVwZGF0ZUF0b21zKCk7IC8vIFBvcHVsYXRlIGZhdm91cml0ZXMgYW5kIGhpc3Rvcnkgb24gZmlyc3QgbW91bnRcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBhdXRoQ2hlY2soKTtcclxuICB9LCBbcm91dGVyLnBhdGhuYW1lXSk7XHJcblxyXG4gIHJldHVybiA8Pntwcm9wcy5jaGlsZHJlbn08Lz47XHJcbn1cclxuIl0sIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJvdXRlciIsInVzZUF0b20iLCJmYXZvdXJpdGVzQXRvbSIsInNlYXJjaEhpc3RvcnlBdG9tIiwiZ2V0RmF2b3VyaXRlcyIsImdldEhpc3RvcnkiLCJnZXRUb2tlbiIsIlBVQkxJQ19QQVRIUyIsIlJvdXRlR3VhcmQiLCJwcm9wcyIsInJvdXRlciIsImZhdm91cml0ZXMiLCJzZXRGYXZvdXJpdGVzIiwic2VhcmNoSGlzdG9yeSIsInNldFNlYXJjaEhpc3RvcnkiLCJ1cGRhdGVBdG9tcyIsInRva2VuIiwiZmF2cyIsImhpc3QiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJhdXRoQ2hlY2siLCJwYXRoIiwicGF0aG5hbWUiLCJpbmNsdWRlcyIsInB1c2giLCJjaGlsZHJlbiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./components/RouteGuard.js\n");

/***/ }),

/***/ "./components/mainNav.js":
/*!*******************************!*\
  !*** ./components/mainNav.js ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MainNav)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ \"./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! __barrel_optimize__?names=Nav,Navbar!=!react-bootstrap */ \"__barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\");\n/* harmony import */ var _lib_authenticate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/authenticate */ \"./lib/authenticate.js\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../store */ \"./store.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/link */ \"./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_1__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__]);\n([jotai__WEBPACK_IMPORTED_MODULE_1__, _lib_authenticate__WEBPACK_IMPORTED_MODULE_3__, _store__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\nfunction MainNav() {\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_1__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_4__.searchHistoryAtom);\n    const [isLoggedIn, setIsLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)({\n        \"MainNav.useEffect\": ()=>{\n            // update on route change to reflect login state\n            const handleRouteChange = {\n                \"MainNav.useEffect.handleRouteChange\": ()=>{\n                    setIsLoggedIn(!!(0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_3__.readToken)());\n                }\n            }[\"MainNav.useEffect.handleRouteChange\"];\n            handleRouteChange(); // check on first render\n            router.events.on('routeChangeComplete', handleRouteChange); // check on every route change\n            return ({\n                \"MainNav.useEffect\": ()=>{\n                    router.events.off('routeChangeComplete', handleRouteChange);\n                }\n            })[\"MainNav.useEffect\"];\n        }\n    }[\"MainNav.useEffect\"], [\n        router.events\n    ]);\n    function logout() {\n        setSearchHistory([]);\n        (0,_lib_authenticate__WEBPACK_IMPORTED_MODULE_3__.removeToken)();\n        setIsLoggedIn(false);\n        router.push('/login');\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar, {\n        bg: \"light\",\n        expand: \"lg\",\n        className: \"fixed-top\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Brand, {\n                as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                href: \"/\",\n                children: \"Tanmay Savaj\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                lineNumber: 37,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Toggle, {\n                \"aria-controls\": \"main-navbar\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                lineNumber: 38,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Navbar.Collapse, {\n                id: \"main-navbar\",\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav, {\n                        className: \"me-auto\",\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                            as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                            href: \"/\",\n                            children: \"Home\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                            lineNumber: 41,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                        lineNumber: 40,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav, {\n                        children: !isLoggedIn ? /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                                    as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                                    href: \"/register\",\n                                    children: \"Register\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                                    lineNumber: 46,\n                                    columnNumber: 15\n                                }, this),\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                                    as: (next_link__WEBPACK_IMPORTED_MODULE_6___default()),\n                                    href: \"/login\",\n                                    children: \"Log In\"\n                                }, void 0, false, {\n                                    fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                                    lineNumber: 47,\n                                    columnNumber: 15\n                                }, this)\n                            ]\n                        }, void 0, true) : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Nav_Navbar_react_bootstrap__WEBPACK_IMPORTED_MODULE_7__.Nav.Link, {\n                            onClick: logout,\n                            children: \"Logout\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                            lineNumber: 50,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                        lineNumber: 43,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\components\\\\mainNav.js\",\n        lineNumber: 36,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL21haW5OYXYuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBZ0M7QUFDUTtBQUNNO0FBQ2U7QUFDaEI7QUFDRDtBQUNmO0FBRWQsU0FBU1U7SUFDdEIsTUFBTSxDQUFDQyxlQUFlQyxpQkFBaUIsR0FBR1osOENBQU9BLENBQUNNLHFEQUFpQkE7SUFDbkUsTUFBTSxDQUFDTyxZQUFZQyxjQUFjLEdBQUdOLCtDQUFRQSxDQUFDO0lBQzdDLE1BQU1PLFNBQVNkLHNEQUFTQTtJQUV4Qk0sZ0RBQVNBOzZCQUFDO1lBQ1IsZ0RBQWdEO1lBQ2hELE1BQU1TO3VEQUFvQjtvQkFDeEJGLGNBQWMsQ0FBQyxDQUFDViw0REFBU0E7Z0JBQzNCOztZQUVBWSxxQkFBcUIsd0JBQXdCO1lBQzdDRCxPQUFPRSxNQUFNLENBQUNDLEVBQUUsQ0FBQyx1QkFBdUJGLG9CQUFvQiw4QkFBOEI7WUFFMUY7cUNBQU87b0JBQ0xELE9BQU9FLE1BQU0sQ0FBQ0UsR0FBRyxDQUFDLHVCQUF1Qkg7Z0JBQzNDOztRQUNGOzRCQUFHO1FBQUNELE9BQU9FLE1BQU07S0FBQztJQUVsQixTQUFTRztRQUNQUixpQkFBaUIsRUFBRTtRQUNuQlAsOERBQVdBO1FBQ1hTLGNBQWM7UUFDZEMsT0FBT00sSUFBSSxDQUFDO0lBQ2Q7SUFFQSxxQkFDRSw4REFBQ25CLHFGQUFNQTtRQUFDb0IsSUFBRztRQUFRQyxRQUFPO1FBQUtDLFdBQVU7OzBCQUN2Qyw4REFBQ3RCLHFGQUFNQSxDQUFDdUIsS0FBSztnQkFBQ0MsSUFBSWpCLGtEQUFJQTtnQkFBRWtCLE1BQUs7MEJBQUk7Ozs7OzswQkFDakMsOERBQUN6QixxRkFBTUEsQ0FBQzBCLE1BQU07Z0JBQUNDLGlCQUFjOzs7Ozs7MEJBQzdCLDhEQUFDM0IscUZBQU1BLENBQUM0QixRQUFRO2dCQUFDQyxJQUFHOztrQ0FDbEIsOERBQUM1QixrRkFBR0E7d0JBQUNxQixXQUFVO2tDQUNiLDRFQUFDckIsa0ZBQUdBLENBQUNNLElBQUk7NEJBQUNpQixJQUFJakIsa0RBQUlBOzRCQUFFa0IsTUFBSztzQ0FBSTs7Ozs7Ozs7Ozs7a0NBRS9CLDhEQUFDeEIsa0ZBQUdBO2tDQUNELENBQUNVLDJCQUNBOzs4Q0FDRSw4REFBQ1Ysa0ZBQUdBLENBQUNNLElBQUk7b0NBQUNpQixJQUFJakIsa0RBQUlBO29DQUFFa0IsTUFBSzs4Q0FBWTs7Ozs7OzhDQUNyQyw4REFBQ3hCLGtGQUFHQSxDQUFDTSxJQUFJO29DQUFDaUIsSUFBSWpCLGtEQUFJQTtvQ0FBRWtCLE1BQUs7OENBQVM7Ozs7Ozs7eURBR3BDLDhEQUFDeEIsa0ZBQUdBLENBQUNNLElBQUk7NEJBQUN1QixTQUFTWjtzQ0FBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFNdkMiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQURNSU5cXERlc2t0b3BcXFdlYjQyMlxcQXNzLTZcXGFzc2lnbm1lbnQtNlxcY29tcG9uZW50c1xcbWFpbk5hdi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VBdG9tIH0gZnJvbSAnam90YWknO1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcic7XHJcbmltcG9ydCB7IE5hdmJhciwgTmF2IH0gZnJvbSAncmVhY3QtYm9vdHN0cmFwJztcclxuaW1wb3J0IHsgcmVhZFRva2VuLCByZW1vdmVUb2tlbiB9IGZyb20gJy4uL2xpYi9hdXRoZW50aWNhdGUnO1xyXG5pbXBvcnQgeyBzZWFyY2hIaXN0b3J5QXRvbSB9IGZyb20gJy4uL3N0b3JlJztcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1haW5OYXYoKSB7XHJcbiAgY29uc3QgW3NlYXJjaEhpc3RvcnksIHNldFNlYXJjaEhpc3RvcnldID0gdXNlQXRvbShzZWFyY2hIaXN0b3J5QXRvbSk7XHJcbiAgY29uc3QgW2lzTG9nZ2VkSW4sIHNldElzTG9nZ2VkSW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgLy8gdXBkYXRlIG9uIHJvdXRlIGNoYW5nZSB0byByZWZsZWN0IGxvZ2luIHN0YXRlXHJcbiAgICBjb25zdCBoYW5kbGVSb3V0ZUNoYW5nZSA9ICgpID0+IHtcclxuICAgICAgc2V0SXNMb2dnZWRJbighIXJlYWRUb2tlbigpKTtcclxuICAgIH07XHJcblxyXG4gICAgaGFuZGxlUm91dGVDaGFuZ2UoKTsgLy8gY2hlY2sgb24gZmlyc3QgcmVuZGVyXHJcbiAgICByb3V0ZXIuZXZlbnRzLm9uKCdyb3V0ZUNoYW5nZUNvbXBsZXRlJywgaGFuZGxlUm91dGVDaGFuZ2UpOyAvLyBjaGVjayBvbiBldmVyeSByb3V0ZSBjaGFuZ2VcclxuXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICByb3V0ZXIuZXZlbnRzLm9mZigncm91dGVDaGFuZ2VDb21wbGV0ZScsIGhhbmRsZVJvdXRlQ2hhbmdlKTtcclxuICAgIH07XHJcbiAgfSwgW3JvdXRlci5ldmVudHNdKTtcclxuXHJcbiAgZnVuY3Rpb24gbG9nb3V0KCkge1xyXG4gICAgc2V0U2VhcmNoSGlzdG9yeShbXSk7XHJcbiAgICByZW1vdmVUb2tlbigpO1xyXG4gICAgc2V0SXNMb2dnZWRJbihmYWxzZSk7XHJcbiAgICByb3V0ZXIucHVzaCgnL2xvZ2luJyk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPE5hdmJhciBiZz1cImxpZ2h0XCIgZXhwYW5kPVwibGdcIiBjbGFzc05hbWU9XCJmaXhlZC10b3BcIj5cclxuICAgICAgPE5hdmJhci5CcmFuZCBhcz17TGlua30gaHJlZj1cIi9cIj5UYW5tYXkgU2F2YWo8L05hdmJhci5CcmFuZD5cclxuICAgICAgPE5hdmJhci5Ub2dnbGUgYXJpYS1jb250cm9scz1cIm1haW4tbmF2YmFyXCIgLz5cclxuICAgICAgPE5hdmJhci5Db2xsYXBzZSBpZD1cIm1haW4tbmF2YmFyXCI+XHJcbiAgICAgICAgPE5hdiBjbGFzc05hbWU9XCJtZS1hdXRvXCI+XHJcbiAgICAgICAgICA8TmF2LkxpbmsgYXM9e0xpbmt9IGhyZWY9XCIvXCI+SG9tZTwvTmF2Lkxpbms+XHJcbiAgICAgICAgPC9OYXY+XHJcbiAgICAgICAgPE5hdj5cclxuICAgICAgICAgIHshaXNMb2dnZWRJbiA/IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8TmF2LkxpbmsgYXM9e0xpbmt9IGhyZWY9XCIvcmVnaXN0ZXJcIj5SZWdpc3RlcjwvTmF2Lkxpbms+XHJcbiAgICAgICAgICAgICAgPE5hdi5MaW5rIGFzPXtMaW5rfSBocmVmPVwiL2xvZ2luXCI+TG9nIEluPC9OYXYuTGluaz5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8TmF2Lkxpbmsgb25DbGljaz17bG9nb3V0fT5Mb2dvdXQ8L05hdi5MaW5rPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L05hdj5cclxuICAgICAgPC9OYXZiYXIuQ29sbGFwc2U+XHJcbiAgICA8L05hdmJhcj5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJ1c2VBdG9tIiwidXNlUm91dGVyIiwiTmF2YmFyIiwiTmF2IiwicmVhZFRva2VuIiwicmVtb3ZlVG9rZW4iLCJzZWFyY2hIaXN0b3J5QXRvbSIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTGluayIsIk1haW5OYXYiLCJzZWFyY2hIaXN0b3J5Iiwic2V0U2VhcmNoSGlzdG9yeSIsImlzTG9nZ2VkSW4iLCJzZXRJc0xvZ2dlZEluIiwicm91dGVyIiwiaGFuZGxlUm91dGVDaGFuZ2UiLCJldmVudHMiLCJvbiIsIm9mZiIsImxvZ291dCIsInB1c2giLCJiZyIsImV4cGFuZCIsImNsYXNzTmFtZSIsIkJyYW5kIiwiYXMiLCJocmVmIiwiVG9nZ2xlIiwiYXJpYS1jb250cm9scyIsIkNvbGxhcHNlIiwiaWQiLCJvbkNsaWNrIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./components/mainNav.js\n");

/***/ }),

/***/ "./lib/authenticate.js":
/*!*****************************!*\
  !*** ./lib/authenticate.js ***!
  \*****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   authenticateUser: () => (/* binding */ authenticateUser),\n/* harmony export */   getToken: () => (/* binding */ getToken),\n/* harmony export */   isAuthenticated: () => (/* binding */ isAuthenticated),\n/* harmony export */   readToken: () => (/* binding */ readToken),\n/* harmony export */   registerUser: () => (/* binding */ registerUser),\n/* harmony export */   removeToken: () => (/* binding */ removeToken),\n/* harmony export */   setToken: () => (/* binding */ setToken)\n/* harmony export */ });\n/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jwt-decode */ \"jwt-decode\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jwt_decode__WEBPACK_IMPORTED_MODULE_0__]);\njwt_decode__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nfunction getToken() {\n    return localStorage.getItem(\"access_token\");\n}\nfunction setToken(token) {\n    localStorage.setItem(\"access_token\", token);\n}\nfunction removeToken() {\n    localStorage.removeItem(\"access_token\");\n}\nfunction readToken() {\n    const token = getToken();\n    return token ? (0,jwt_decode__WEBPACK_IMPORTED_MODULE_0__[\"default\"])(token) : null;\n}\n// Check if the user is authenticated\nfunction isAuthenticated() {\n    return !!getToken();\n}\n// Login function\nasync function authenticateUser(user, password) {\n    const res = await fetch(`${\"https://user-api-seven-drab.vercel.app/api/user\"}/login`, {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/json\"\n        },\n        body: JSON.stringify({\n            userName: user,\n            password\n        })\n    });\n    if (res.status === 200) {\n        const data = await res.json();\n        setToken(data.token);\n        return true;\n    } else {\n        const err = await res.json();\n        throw new Error(err.message || \"Invalid login.\");\n    }\n}\n// Register function\nasync function registerUser(user, password, password2) {\n    const res = await fetch(`${\"https://user-api-seven-drab.vercel.app/api/user\"}/register`, {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/json\"\n        },\n        body: JSON.stringify({\n            userName: user,\n            password,\n            password2\n        })\n    });\n    if (res.status === 200) {\n        return true;\n    }\n    return false;\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvYXV0aGVudGljYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQW1DO0FBRTVCLFNBQVNDO0lBQ2QsT0FBT0MsYUFBYUMsT0FBTyxDQUFDO0FBQzlCO0FBRU8sU0FBU0MsU0FBU0MsS0FBSztJQUM1QkgsYUFBYUksT0FBTyxDQUFDLGdCQUFnQkQ7QUFDdkM7QUFFTyxTQUFTRTtJQUNkTCxhQUFhTSxVQUFVLENBQUM7QUFDMUI7QUFFTyxTQUFTQztJQUNkLE1BQU1KLFFBQVFKO0lBQ2QsT0FBT0ksUUFBUUwsc0RBQVNBLENBQUNLLFNBQVM7QUFDcEM7QUFJQSxxQ0FBcUM7QUFDOUIsU0FBU0s7SUFDZCxPQUFPLENBQUMsQ0FBQ1Q7QUFDWDtBQUVBLGlCQUFpQjtBQUNWLGVBQWVVLGlCQUFpQkMsSUFBSSxFQUFFQyxRQUFRO0lBQ25ELE1BQU1DLE1BQU0sTUFBTUMsTUFBTSxHQUFHQyxpREFBK0IsQ0FBQyxNQUFNLENBQUMsRUFBRTtRQUNsRUcsUUFBUTtRQUNSQyxTQUFTO1lBQUUsZ0JBQWdCO1FBQW1CO1FBQzlDQyxNQUFNQyxLQUFLQyxTQUFTLENBQUM7WUFBRUMsVUFBVVo7WUFBTUM7UUFBUztJQUNsRDtJQUVBLElBQUlDLElBQUlXLE1BQU0sS0FBSyxLQUFLO1FBQ3RCLE1BQU1DLE9BQU8sTUFBTVosSUFBSWEsSUFBSTtRQUMzQnZCLFNBQVNzQixLQUFLckIsS0FBSztRQUNuQixPQUFPO0lBQ1QsT0FBTztRQUNMLE1BQU11QixNQUFNLE1BQU1kLElBQUlhLElBQUk7UUFDMUIsTUFBTSxJQUFJRSxNQUFNRCxJQUFJRSxPQUFPLElBQUk7SUFDakM7QUFDRjtBQUdBLG9CQUFvQjtBQUNiLGVBQWVDLGFBQWFuQixJQUFJLEVBQUVDLFFBQVEsRUFBRW1CLFNBQVM7SUFDMUQsTUFBTWxCLE1BQU0sTUFBTUMsTUFBTSxHQUFHQyxpREFBK0IsQ0FBQyxTQUFTLENBQUMsRUFBRTtRQUNyRUcsUUFBUTtRQUNSQyxTQUFTO1lBQUUsZ0JBQWdCO1FBQW1CO1FBQzlDQyxNQUFNQyxLQUFLQyxTQUFTLENBQUM7WUFDbkJDLFVBQVVaO1lBQ1ZDO1lBQ0FtQjtRQUNGO0lBQ0Y7SUFFQSxJQUFJbEIsSUFBSVcsTUFBTSxLQUFLLEtBQUs7UUFDdEIsT0FBTztJQUNUO0lBRUEsT0FBTztBQUNUIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXEFETUlOXFxEZXNrdG9wXFxXZWI0MjJcXEFzcy02XFxhc3NpZ25tZW50LTZcXGxpYlxcYXV0aGVudGljYXRlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBqd3REZWNvZGUgZnJvbSBcImp3dC1kZWNvZGVcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRUb2tlbigpIHtcclxuICByZXR1cm4gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJhY2Nlc3NfdG9rZW5cIik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZXRUb2tlbih0b2tlbikge1xyXG4gIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYWNjZXNzX3Rva2VuXCIsIHRva2VuKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHJlbW92ZVRva2VuKCkge1xyXG4gIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwiYWNjZXNzX3Rva2VuXCIpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcmVhZFRva2VuKCkge1xyXG4gIGNvbnN0IHRva2VuID0gZ2V0VG9rZW4oKTtcclxuICByZXR1cm4gdG9rZW4gPyBqd3REZWNvZGUodG9rZW4pIDogbnVsbDtcclxufVxyXG5cclxuXHJcblxyXG4vLyBDaGVjayBpZiB0aGUgdXNlciBpcyBhdXRoZW50aWNhdGVkXHJcbmV4cG9ydCBmdW5jdGlvbiBpc0F1dGhlbnRpY2F0ZWQoKSB7XHJcbiAgcmV0dXJuICEhZ2V0VG9rZW4oKTtcclxufVxyXG5cclxuLy8gTG9naW4gZnVuY3Rpb25cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGF1dGhlbnRpY2F0ZVVzZXIodXNlciwgcGFzc3dvcmQpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19BUElfVVJMfS9sb2dpbmAsIHtcclxuICAgIG1ldGhvZDogXCJQT1NUXCIsXHJcbiAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHVzZXJOYW1lOiB1c2VyLCBwYXNzd29yZCB9KSxcclxuICB9KTtcclxuXHJcbiAgaWYgKHJlcy5zdGF0dXMgPT09IDIwMCkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICBzZXRUb2tlbihkYXRhLnRva2VuKTtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjb25zdCBlcnIgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKGVyci5tZXNzYWdlIHx8IFwiSW52YWxpZCBsb2dpbi5cIik7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuLy8gUmVnaXN0ZXIgZnVuY3Rpb25cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZ2lzdGVyVXNlcih1c2VyLCBwYXNzd29yZCwgcGFzc3dvcmQyKSB7XHJcbiAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7cHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTH0vcmVnaXN0ZXJgLCB7XHJcbiAgICBtZXRob2Q6IFwiUE9TVFwiLFxyXG4gICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICB1c2VyTmFtZTogdXNlcixcclxuICAgICAgcGFzc3dvcmQsXHJcbiAgICAgIHBhc3N3b3JkMixcclxuICAgIH0pLFxyXG4gIH0pO1xyXG5cclxuICBpZiAocmVzLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcblxyXG4gIHJldHVybiBmYWxzZTtcclxufVxyXG4iXSwibmFtZXMiOlsiand0RGVjb2RlIiwiZ2V0VG9rZW4iLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwic2V0VG9rZW4iLCJ0b2tlbiIsInNldEl0ZW0iLCJyZW1vdmVUb2tlbiIsInJlbW92ZUl0ZW0iLCJyZWFkVG9rZW4iLCJpc0F1dGhlbnRpY2F0ZWQiLCJhdXRoZW50aWNhdGVVc2VyIiwidXNlciIsInBhc3N3b3JkIiwicmVzIiwiZmV0Y2giLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfQVBJX1VSTCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsInVzZXJOYW1lIiwic3RhdHVzIiwiZGF0YSIsImpzb24iLCJlcnIiLCJFcnJvciIsIm1lc3NhZ2UiLCJyZWdpc3RlclVzZXIiLCJwYXNzd29yZDIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./lib/authenticate.js\n");

/***/ }),

/***/ "./lib/userData.js":
/*!*************************!*\
  !*** ./lib/userData.js ***!
  \*************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   addToFavourites: () => (/* binding */ addToFavourites),\n/* harmony export */   addToHistory: () => (/* binding */ addToHistory),\n/* harmony export */   getFavourites: () => (/* binding */ getFavourites),\n/* harmony export */   getHistory: () => (/* binding */ getHistory),\n/* harmony export */   removeFromFavourites: () => (/* binding */ removeFromFavourites),\n/* harmony export */   removeFromHistory: () => (/* binding */ removeFromHistory)\n/* harmony export */ });\n/* harmony import */ var _authenticate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./authenticate */ \"./lib/authenticate.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_authenticate__WEBPACK_IMPORTED_MODULE_0__]);\n_authenticate__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst API_URL = \"https://user-api-seven-drab.vercel.app/api/user\";\n// Helper to add headers\nfunction getAuthHeaders() {\n    return {\n        \"Content-Type\": \"application/json\",\n        Authorization: `JWT ${(0,_authenticate__WEBPACK_IMPORTED_MODULE_0__.getToken)()}`\n    };\n}\n// Add to favourites\nasync function addToFavourites(id) {\n    const res = await fetch(`${API_URL}/favourites/${id}`, {\n        method: \"PUT\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Remove from favourites\nasync function removeFromFavourites(id) {\n    const res = await fetch(`${API_URL}/favourites/${id}`, {\n        method: \"DELETE\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Get favourites\nasync function getFavourites() {\n    const res = await fetch(`${API_URL}/favourites`, {\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Add to history\nasync function addToHistory(id) {\n    const res = await fetch(`${API_URL}/history/${id}`, {\n        method: \"PUT\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Remove from history\nasync function removeFromHistory(id) {\n    const res = await fetch(`${API_URL}/history/${id}`, {\n        method: \"DELETE\",\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n// Get history\nasync function getHistory() {\n    const res = await fetch(`${API_URL}/history`, {\n        headers: getAuthHeaders()\n    });\n    return res.status === 200 ? res.json() : [];\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9saWIvdXNlckRhdGEuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUEwQztBQUUxQyxNQUFNQyxVQUFVQyxpREFBK0I7QUFFL0Msd0JBQXdCO0FBQ3hCLFNBQVNHO0lBQ1AsT0FBTztRQUNMLGdCQUFnQjtRQUNoQkMsZUFBZSxDQUFDLElBQUksRUFBRU4sdURBQVFBLElBQUk7SUFDcEM7QUFDRjtBQUVBLG9CQUFvQjtBQUNiLGVBQWVPLGdCQUFnQkMsRUFBRTtJQUN0QyxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sR0FBR1QsUUFBUSxZQUFZLEVBQUVPLElBQUksRUFBRTtRQUNyREcsUUFBUTtRQUNSQyxTQUFTUDtJQUNYO0lBRUEsT0FBT0ksSUFBSUksTUFBTSxLQUFLLE1BQU1KLElBQUlLLElBQUksS0FBSyxFQUFFO0FBQzdDO0FBRUEseUJBQXlCO0FBQ2xCLGVBQWVDLHFCQUFxQlAsRUFBRTtJQUMzQyxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sR0FBR1QsUUFBUSxZQUFZLEVBQUVPLElBQUksRUFBRTtRQUNyREcsUUFBUTtRQUNSQyxTQUFTUDtJQUNYO0lBRUEsT0FBT0ksSUFBSUksTUFBTSxLQUFLLE1BQU1KLElBQUlLLElBQUksS0FBSyxFQUFFO0FBQzdDO0FBRUEsaUJBQWlCO0FBQ1YsZUFBZUU7SUFDcEIsTUFBTVAsTUFBTSxNQUFNQyxNQUFNLEdBQUdULFFBQVEsV0FBVyxDQUFDLEVBQUU7UUFDL0NXLFNBQVNQO0lBQ1g7SUFFQSxPQUFPSSxJQUFJSSxNQUFNLEtBQUssTUFBTUosSUFBSUssSUFBSSxLQUFLLEVBQUU7QUFDN0M7QUFFQSxpQkFBaUI7QUFDVixlQUFlRyxhQUFhVCxFQUFFO0lBQ25DLE1BQU1DLE1BQU0sTUFBTUMsTUFBTSxHQUFHVCxRQUFRLFNBQVMsRUFBRU8sSUFBSSxFQUFFO1FBQ2xERyxRQUFRO1FBQ1JDLFNBQVNQO0lBQ1g7SUFFQSxPQUFPSSxJQUFJSSxNQUFNLEtBQUssTUFBTUosSUFBSUssSUFBSSxLQUFLLEVBQUU7QUFDN0M7QUFFQSxzQkFBc0I7QUFDZixlQUFlSSxrQkFBa0JWLEVBQUU7SUFDeEMsTUFBTUMsTUFBTSxNQUFNQyxNQUFNLEdBQUdULFFBQVEsU0FBUyxFQUFFTyxJQUFJLEVBQUU7UUFDbERHLFFBQVE7UUFDUkMsU0FBU1A7SUFDWDtJQUVBLE9BQU9JLElBQUlJLE1BQU0sS0FBSyxNQUFNSixJQUFJSyxJQUFJLEtBQUssRUFBRTtBQUM3QztBQUVBLGNBQWM7QUFDUCxlQUFlSztJQUNwQixNQUFNVixNQUFNLE1BQU1DLE1BQU0sR0FBR1QsUUFBUSxRQUFRLENBQUMsRUFBRTtRQUM1Q1csU0FBU1A7SUFDWDtJQUVBLE9BQU9JLElBQUlJLE1BQU0sS0FBSyxNQUFNSixJQUFJSyxJQUFJLEtBQUssRUFBRTtBQUM3QyIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBRE1JTlxcRGVza3RvcFxcV2ViNDIyXFxBc3MtNlxcYXNzaWdubWVudC02XFxsaWJcXHVzZXJEYXRhLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdldFRva2VuIH0gZnJvbSBcIi4vYXV0aGVudGljYXRlXCI7XHJcblxyXG5jb25zdCBBUElfVVJMID0gcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX1VSTDtcclxuXHJcbi8vIEhlbHBlciB0byBhZGQgaGVhZGVyc1xyXG5mdW5jdGlvbiBnZXRBdXRoSGVhZGVycygpIHtcclxuICByZXR1cm4ge1xyXG4gICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICBBdXRob3JpemF0aW9uOiBgSldUICR7Z2V0VG9rZW4oKX1gLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIEFkZCB0byBmYXZvdXJpdGVzXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0Zhdm91cml0ZXMoaWQpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfVVJMfS9mYXZvdXJpdGVzLyR7aWR9YCwge1xyXG4gICAgbWV0aG9kOiBcIlBVVFwiLFxyXG4gICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwMCA/IHJlcy5qc29uKCkgOiBbXTtcclxufVxyXG5cclxuLy8gUmVtb3ZlIGZyb20gZmF2b3VyaXRlc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlRnJvbUZhdm91cml0ZXMoaWQpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfVVJMfS9mYXZvdXJpdGVzLyR7aWR9YCwge1xyXG4gICAgbWV0aG9kOiBcIkRFTEVURVwiLFxyXG4gICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwMCA/IHJlcy5qc29uKCkgOiBbXTtcclxufVxyXG5cclxuLy8gR2V0IGZhdm91cml0ZXNcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEZhdm91cml0ZXMoKSB7XHJcbiAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX1VSTH0vZmF2b3VyaXRlc2AsIHtcclxuICAgIGhlYWRlcnM6IGdldEF1dGhIZWFkZXJzKCksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiByZXMuc3RhdHVzID09PSAyMDAgPyByZXMuanNvbigpIDogW107XHJcbn1cclxuXHJcbi8vIEFkZCB0byBoaXN0b3J5XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0hpc3RvcnkoaWQpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfVVJMfS9oaXN0b3J5LyR7aWR9YCwge1xyXG4gICAgbWV0aG9kOiBcIlBVVFwiLFxyXG4gICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwMCA/IHJlcy5qc29uKCkgOiBbXTtcclxufVxyXG5cclxuLy8gUmVtb3ZlIGZyb20gaGlzdG9yeVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlRnJvbUhpc3RvcnkoaWQpIHtcclxuICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtBUElfVVJMfS9oaXN0b3J5LyR7aWR9YCwge1xyXG4gICAgbWV0aG9kOiBcIkRFTEVURVwiLFxyXG4gICAgaGVhZGVyczogZ2V0QXV0aEhlYWRlcnMoKSxcclxuICB9KTtcclxuXHJcbiAgcmV0dXJuIHJlcy5zdGF0dXMgPT09IDIwMCA/IHJlcy5qc29uKCkgOiBbXTtcclxufVxyXG5cclxuLy8gR2V0IGhpc3RvcnlcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEhpc3RvcnkoKSB7XHJcbiAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QVBJX1VSTH0vaGlzdG9yeWAsIHtcclxuICAgIGhlYWRlcnM6IGdldEF1dGhIZWFkZXJzKCksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiByZXMuc3RhdHVzID09PSAyMDAgPyByZXMuanNvbigpIDogW107XHJcbn1cclxuIl0sIm5hbWVzIjpbImdldFRva2VuIiwiQVBJX1VSTCIsInByb2Nlc3MiLCJlbnYiLCJORVhUX1BVQkxJQ19BUElfVVJMIiwiZ2V0QXV0aEhlYWRlcnMiLCJBdXRob3JpemF0aW9uIiwiYWRkVG9GYXZvdXJpdGVzIiwiaWQiLCJyZXMiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJzdGF0dXMiLCJqc29uIiwicmVtb3ZlRnJvbUZhdm91cml0ZXMiLCJnZXRGYXZvdXJpdGVzIiwiYWRkVG9IaXN0b3J5IiwicmVtb3ZlRnJvbUhpc3RvcnkiLCJnZXRIaXN0b3J5Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./lib/userData.js\n");

/***/ }),

/***/ "./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F_error&preferredRegion=&absolutePagePath=.%2Fnode_modules%5Cnext%5Cdist%5Cpages%5C_error.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F_error&preferredRegion=&absolutePagePath=.%2Fnode_modules%5Cnext%5Cdist%5Cpages%5C_error.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D! ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),\n/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),\n/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),\n/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),\n/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),\n/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),\n/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),\n/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/pages/module.compiled */ \"./node_modules/next/dist/server/route-modules/pages/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! private-next-pages/_document */ \"./pages/_document.js\");\n/* harmony import */ var private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! private-next-pages/_app */ \"./pages/_app.js\");\n/* harmony import */ var _node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules\\next\\dist\\pages\\_error.js */ \"./node_modules/next/dist/pages/_error.js\");\n/* harmony import */ var _node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__]);\nprivate_next_pages_app__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n// Import the app and document modules.\n\n\n// Import the userland code.\n\n// Re-export the component (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'default'));\n// Re-export methods.\nconst getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticProps');\nconst getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'getStaticPaths');\nconst getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'getServerSideProps');\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'config');\nconst reportWebVitals = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'reportWebVitals');\n// Re-export legacy methods.\nconst unstable_getStaticProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticProps');\nconst unstable_getStaticPaths = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticPaths');\nconst unstable_getStaticParams = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getStaticParams');\nconst unstable_getServerProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerProps');\nconst unstable_getServerSideProps = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__, 'unstable_getServerSideProps');\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_route_modules_pages_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES,\n        page: \"/_error\",\n        pathname: \"/_error\",\n        // The following aren't used in production.\n        bundlePath: '',\n        filename: ''\n    },\n    components: {\n        // default export might not exist when optimized for data only\n        App: private_next_pages_app__WEBPACK_IMPORTED_MODULE_4__[\"default\"],\n        Document: private_next_pages_document__WEBPACK_IMPORTED_MODULE_3__[\"default\"]\n    },\n    userland: _node_modules_next_dist_pages_error_js__WEBPACK_IMPORTED_MODULE_5__\n});\n\n//# sourceMappingURL=pages.js.map\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTJnBhZ2U9JTJGX2Vycm9yJnByZWZlcnJlZFJlZ2lvbj0mYWJzb2x1dGVQYWdlUGF0aD0uJTJGbm9kZV9tb2R1bGVzJTVDbmV4dCU1Q2Rpc3QlNUNwYWdlcyU1Q19lcnJvci5qcyZhYnNvbHV0ZUFwcFBhdGg9cHJpdmF0ZS1uZXh0LXBhZ2VzJTJGX2FwcCZhYnNvbHV0ZURvY3VtZW50UGF0aD1wcml2YXRlLW5leHQtcGFnZXMlMkZfZG9jdW1lbnQmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQXdGO0FBQ2hDO0FBQ0U7QUFDMUQ7QUFDeUQ7QUFDVjtBQUMvQztBQUN5RTtBQUN6RTtBQUNBLGlFQUFlLHdFQUFLLENBQUMsbUVBQVEsWUFBWSxFQUFDO0FBQzFDO0FBQ08sdUJBQXVCLHdFQUFLLENBQUMsbUVBQVE7QUFDckMsdUJBQXVCLHdFQUFLLENBQUMsbUVBQVE7QUFDckMsMkJBQTJCLHdFQUFLLENBQUMsbUVBQVE7QUFDekMsZUFBZSx3RUFBSyxDQUFDLG1FQUFRO0FBQzdCLHdCQUF3Qix3RUFBSyxDQUFDLG1FQUFRO0FBQzdDO0FBQ08sZ0NBQWdDLHdFQUFLLENBQUMsbUVBQVE7QUFDOUMsZ0NBQWdDLHdFQUFLLENBQUMsbUVBQVE7QUFDOUMsaUNBQWlDLHdFQUFLLENBQUMsbUVBQVE7QUFDL0MsZ0NBQWdDLHdFQUFLLENBQUMsbUVBQVE7QUFDOUMsb0NBQW9DLHdFQUFLLENBQUMsbUVBQVE7QUFDekQ7QUFDTyx3QkFBd0Isa0dBQWdCO0FBQy9DO0FBQ0EsY0FBYyxrRUFBUztBQUN2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxhQUFhLDhEQUFXO0FBQ3hCLGtCQUFrQixtRUFBZ0I7QUFDbEMsS0FBSztBQUNMLFlBQVk7QUFDWixDQUFDOztBQUVELGlDIiwic291cmNlcyI6WyIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFnZXNSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLW1vZHVsZXMvcGFnZXMvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBob2lzdCB9IGZyb20gXCJuZXh0L2Rpc3QvYnVpbGQvdGVtcGxhdGVzL2hlbHBlcnNcIjtcbi8vIEltcG9ydCB0aGUgYXBwIGFuZCBkb2N1bWVudCBtb2R1bGVzLlxuaW1wb3J0ICogYXMgZG9jdW1lbnQgZnJvbSBcInByaXZhdGUtbmV4dC1wYWdlcy9fZG9jdW1lbnRcIjtcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwicHJpdmF0ZS1uZXh0LXBhZ2VzL19hcHBcIjtcbi8vIEltcG9ydCB0aGUgdXNlcmxhbmQgY29kZS5cbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIuL25vZGVfbW9kdWxlc1xcXFxuZXh0XFxcXGRpc3RcXFxccGFnZXNcXFxcX2Vycm9yLmpzXCI7XG4vLyBSZS1leHBvcnQgdGhlIGNvbXBvbmVudCAoc2hvdWxkIGJlIHRoZSBkZWZhdWx0IGV4cG9ydCkuXG5leHBvcnQgZGVmYXVsdCBob2lzdCh1c2VybGFuZCwgJ2RlZmF1bHQnKTtcbi8vIFJlLWV4cG9ydCBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsICdnZXRTdGF0aWNQcm9wcycpO1xuZXhwb3J0IGNvbnN0IGdldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsICdnZXRTdGF0aWNQYXRocycpO1xuZXhwb3J0IGNvbnN0IGdldFNlcnZlclNpZGVQcm9wcyA9IGhvaXN0KHVzZXJsYW5kLCAnZ2V0U2VydmVyU2lkZVByb3BzJyk7XG5leHBvcnQgY29uc3QgY29uZmlnID0gaG9pc3QodXNlcmxhbmQsICdjb25maWcnKTtcbmV4cG9ydCBjb25zdCByZXBvcnRXZWJWaXRhbHMgPSBob2lzdCh1c2VybGFuZCwgJ3JlcG9ydFdlYlZpdGFscycpO1xuLy8gUmUtZXhwb3J0IGxlZ2FjeSBtZXRob2RzLlxuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1Byb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTdGF0aWNQcm9wcycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhdGhzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTdGF0aWNQYXRocycpO1xuZXhwb3J0IGNvbnN0IHVuc3RhYmxlX2dldFN0YXRpY1BhcmFtcyA9IGhvaXN0KHVzZXJsYW5kLCAndW5zdGFibGVfZ2V0U3RhdGljUGFyYW1zJyk7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyUHJvcHMgPSBob2lzdCh1c2VybGFuZCwgJ3Vuc3RhYmxlX2dldFNlcnZlclByb3BzJyk7XG5leHBvcnQgY29uc3QgdW5zdGFibGVfZ2V0U2VydmVyU2lkZVByb3BzID0gaG9pc3QodXNlcmxhbmQsICd1bnN0YWJsZV9nZXRTZXJ2ZXJTaWRlUHJvcHMnKTtcbi8vIENyZWF0ZSBhbmQgZXhwb3J0IHRoZSByb3V0ZSBtb2R1bGUgdGhhdCB3aWxsIGJlIGNvbnN1bWVkLlxuZXhwb3J0IGNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IFBhZ2VzUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLlBBR0VTLFxuICAgICAgICBwYWdlOiBcIi9fZXJyb3JcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL19lcnJvclwiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6ICcnLFxuICAgICAgICBmaWxlbmFtZTogJydcbiAgICB9LFxuICAgIGNvbXBvbmVudHM6IHtcbiAgICAgICAgLy8gZGVmYXVsdCBleHBvcnQgbWlnaHQgbm90IGV4aXN0IHdoZW4gb3B0aW1pemVkIGZvciBkYXRhIG9ubHlcbiAgICAgICAgQXBwOiBhcHAuZGVmYXVsdCxcbiAgICAgICAgRG9jdW1lbnQ6IGRvY3VtZW50LmRlZmF1bHRcbiAgICB9LFxuICAgIHVzZXJsYW5kXG59KTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFnZXMuanMubWFwIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F_error&preferredRegion=&absolutePagePath=.%2Fnode_modules%5Cnext%5Cdist%5Cpages%5C_error.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/bootstrap.min.css */ \"./styles/bootstrap.min.css\");\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Layout */ \"./components/Layout.js\");\n/* harmony import */ var _components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/RouteGuard */ \"./components/RouteGuard.js\");\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! swr */ \"swr\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout__WEBPACK_IMPORTED_MODULE_2__, _components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__]);\n([_components_Layout__WEBPACK_IMPORTED_MODULE_2__, _components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__, swr__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\nfunction MyApp({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(swr__WEBPACK_IMPORTED_MODULE_4__.SWRConfig, {\n        value: {\n            fetcher: async (url)=>{\n                const res = await fetch(url);\n                if (!res.ok) {\n                    const error = new Error('An error occurred while fetching the data.');\n                    error.info = await res.json();\n                    error.status = res.status;\n                    throw error;\n                }\n                return res.json();\n            }\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_RouteGuard__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n                    lineNumber: 22,\n                    columnNumber: 11\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n                lineNumber: 21,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n            lineNumber: 20,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_app.js\",\n        lineNumber: 8,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFvQztBQUNNO0FBQ1E7QUFDbEI7QUFFaEMsU0FBU0csTUFBTSxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsRUFBRTtJQUNyQyxxQkFDRSw4REFBQ0gsMENBQVNBO1FBQUNJLE9BQU87WUFDaEJDLFNBQVMsT0FBTUM7Z0JBQ2IsTUFBTUMsTUFBTSxNQUFNQyxNQUFNRjtnQkFDeEIsSUFBSSxDQUFDQyxJQUFJRSxFQUFFLEVBQUU7b0JBQ1gsTUFBTUMsUUFBUSxJQUFJQyxNQUFNO29CQUN4QkQsTUFBTUUsSUFBSSxHQUFHLE1BQU1MLElBQUlNLElBQUk7b0JBQzNCSCxNQUFNSSxNQUFNLEdBQUdQLElBQUlPLE1BQU07b0JBQ3pCLE1BQU1KO2dCQUNSO2dCQUNBLE9BQU9ILElBQUlNLElBQUk7WUFDakI7UUFDRjtrQkFDRSw0RUFBQ2QsOERBQVVBO3NCQUNULDRFQUFDRCwwREFBTUE7MEJBQ0wsNEVBQUNJO29CQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUtsQztBQUVBLGlFQUFlRixLQUFLQSxFQUFDIiwic291cmNlcyI6WyJDOlxcVXNlcnNcXEFETUlOXFxEZXNrdG9wXFxXZWI0MjJcXEFzcy02XFxhc3NpZ25tZW50LTZcXHBhZ2VzXFxfYXBwLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnQC9zdHlsZXMvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL0xheW91dCc7XG5pbXBvcnQgUm91dGVHdWFyZCBmcm9tICcuLi9jb21wb25lbnRzL1JvdXRlR3VhcmQnO1xuaW1wb3J0IHsgU1dSQ29uZmlnIH0gZnJvbSAnc3dyJztcblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XG4gIHJldHVybiAoXG4gICAgPFNXUkNvbmZpZyB2YWx1ZT17e1xuICAgICAgZmV0Y2hlcjogYXN5bmMgdXJsID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcbiAgICAgICAgaWYgKCFyZXMub2spIHtcbiAgICAgICAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgZmV0Y2hpbmcgdGhlIGRhdGEuJyk7XG4gICAgICAgICAgZXJyb3IuaW5mbyA9IGF3YWl0IHJlcy5qc29uKCk7XG4gICAgICAgICAgZXJyb3Iuc3RhdHVzID0gcmVzLnN0YXR1cztcbiAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzLmpzb24oKTtcbiAgICAgIH1cbiAgICB9fT5cbiAgICAgIDxSb3V0ZUd1YXJkPlxuICAgICAgICA8TGF5b3V0PlxuICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgICAgPC9MYXlvdXQ+XG4gICAgICA8L1JvdXRlR3VhcmQ+XG4gICAgPC9TV1JDb25maWc+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xuIl0sIm5hbWVzIjpbIkxheW91dCIsIlJvdXRlR3VhcmQiLCJTV1JDb25maWciLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsInZhbHVlIiwiZmV0Y2hlciIsInVybCIsInJlcyIsImZldGNoIiwib2siLCJlcnJvciIsIkVycm9yIiwiaW5mbyIsImpzb24iLCJzdGF0dXMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./pages/_document.js":
/*!****************************!*\
  !*** ./pages/_document.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Document)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/document */ \"./node_modules/next/document.js\");\n/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Document() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {\n        lang: \"en\",\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_document.js\",\n                lineNumber: 6,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"body\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_document.js\",\n                        lineNumber: 8,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {}, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_document.js\",\n                        lineNumber: 9,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_document.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\ADMIN\\\\Desktop\\\\Web422\\\\Ass-6\\\\assignment-6\\\\pages\\\\_document.js\",\n        lineNumber: 5,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fZG9jdW1lbnQuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQTZEO0FBRTlDLFNBQVNJO0lBQ3RCLHFCQUNFLDhEQUFDSiwrQ0FBSUE7UUFBQ0ssTUFBSzs7MEJBQ1QsOERBQUNKLCtDQUFJQTs7Ozs7MEJBQ0wsOERBQUNLOztrQ0FDQyw4REFBQ0osK0NBQUlBOzs7OztrQ0FDTCw4REFBQ0MscURBQVVBOzs7Ozs7Ozs7Ozs7Ozs7OztBQUluQiIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBRE1JTlxcRGVza3RvcFxcV2ViNDIyXFxBc3MtNlxcYXNzaWdubWVudC02XFxwYWdlc1xcX2RvY3VtZW50LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEh0bWwsIEhlYWQsIE1haW4sIE5leHRTY3JpcHQgfSBmcm9tIFwibmV4dC9kb2N1bWVudFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEb2N1bWVudCgpIHtcbiAgcmV0dXJuIChcbiAgICA8SHRtbCBsYW5nPVwiZW5cIj5cbiAgICAgIDxIZWFkIC8+XG4gICAgICA8Ym9keT5cbiAgICAgICAgPE1haW4gLz5cbiAgICAgICAgPE5leHRTY3JpcHQgLz5cbiAgICAgIDwvYm9keT5cbiAgICA8L0h0bWw+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiSHRtbCIsIkhlYWQiLCJNYWluIiwiTmV4dFNjcmlwdCIsIkRvY3VtZW50IiwibGFuZyIsImJvZHkiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_document.js\n");

/***/ }),

/***/ "./store.js":
/*!******************!*\
  !*** ./store.js ***!
  \******************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   favouritesAtom: () => (/* binding */ favouritesAtom),\n/* harmony export */   searchHistoryAtom: () => (/* binding */ searchHistoryAtom)\n/* harmony export */ });\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jotai */ \"jotai\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_0__]);\njotai__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst favouritesAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\nconst searchHistoryAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBNkI7QUFFdEIsTUFBTUMsaUJBQWlCRCwyQ0FBSUEsQ0FBQyxFQUFFLEVBQUU7QUFDaEMsTUFBTUUsb0JBQW9CRiwyQ0FBSUEsQ0FBQyxFQUFFLEVBQUUiLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcQURNSU5cXERlc2t0b3BcXFdlYjQyMlxcQXNzLTZcXGFzc2lnbm1lbnQtNlxcc3RvcmUuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSB9IGZyb20gJ2pvdGFpJztcclxuXHJcbmV4cG9ydCBjb25zdCBmYXZvdXJpdGVzQXRvbSA9IGF0b20oW10pO1xyXG5leHBvcnQgY29uc3Qgc2VhcmNoSGlzdG9yeUF0b20gPSBhdG9tKFtdKTtcclxuIl0sIm5hbWVzIjpbImF0b20iLCJmYXZvdXJpdGVzQXRvbSIsInNlYXJjaEhpc3RvcnlBdG9tIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./store.js\n");

/***/ }),

/***/ "./styles/bootstrap.min.css":
/*!**********************************!*\
  !*** ./styles/bootstrap.min.css ***!
  \**********************************/
/***/ (() => {



/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "@restart/ui/utils":
/*!************************************!*\
  !*** external "@restart/ui/utils" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/utils");

/***/ }),

/***/ "__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/esm/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Container: () => (/* reexport safe */ _Container__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var _Container__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Container */ "./node_modules/react-bootstrap/esm/Container.js");



/***/ }),

/***/ "__barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js":
/*!******************************************************************************************!*\
  !*** __barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   Nav: () => (/* reexport safe */ _Nav__WEBPACK_IMPORTED_MODULE_0__[\"default\"]),\n/* harmony export */   Navbar: () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_1__[\"default\"])\n/* harmony export */ });\n/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Nav */ \"./node_modules/react-bootstrap/esm/Nav.js\");\n/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Navbar */ \"./node_modules/react-bootstrap/esm/Navbar.js\");\n\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiX19iYXJyZWxfb3B0aW1pemVfXz9uYW1lcz1OYXYsTmF2YmFyIT0hLi9ub2RlX21vZHVsZXMvcmVhY3QtYm9vdHN0cmFwL2VzbS9pbmRleC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUNzQyIsInNvdXJjZXMiOlsiQzpcXFVzZXJzXFxBRE1JTlxcRGVza3RvcFxcV2ViNDIyXFxBc3MtNlxcYXNzaWdubWVudC02XFxub2RlX21vZHVsZXNcXHJlYWN0LWJvb3RzdHJhcFxcZXNtXFxpbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2IH0gZnJvbSBcIi4vTmF2XCJcbmV4cG9ydCB7IGRlZmF1bHQgYXMgTmF2YmFyIH0gZnJvbSBcIi4vTmF2YmFyXCIiXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbMF0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///__barrel_optimize__?names=Nav,Navbar!=!./node_modules/react-bootstrap/esm/index.js\n");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "jotai":
/*!************************!*\
  !*** external "jotai" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("jotai");;

/***/ }),

/***/ "jwt-decode":
/*!*****************************!*\
  !*** external "jwt-decode" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = import("jwt-decode");;

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "swr":
/*!**********************!*\
  !*** external "swr" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("./webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap"], () => (__webpack_exec__("./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES&page=%2F_error&preferredRegion=&absolutePagePath=.%2Fnode_modules%5Cnext%5Cdist%5Cpages%5C_error.js&absoluteAppPath=private-next-pages%2F_app&absoluteDocumentPath=private-next-pages%2F_document&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();